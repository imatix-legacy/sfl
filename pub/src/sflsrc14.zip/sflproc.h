/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflproc.h
    Title:      Process control functions
    Package:    Standard Function Library (SFL)

    Written:    96/09/09  Pieter Hintjens <ph@imatix.com>
    Revised:    96/11/23  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Provides functions to create and manage processes.  The main
                set of functions lets you create, monitor, and end processes.
                A secondary function lets you run the current process as a
                background process.  Some of the code in process_server()
                came from the book "Internetworking With TCP/IP Volume III:
                Client-Server Programming And Applications, BSD Socket
                Version" by Douglas E. Comer and David L. Stevens, published
                1993 by Prentice-Hall Inc.  ISBN 0-13-020272-X.  Changes for
                OS/2 were made by Ewen McNeill <ewen@naos.co.nz>.

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLPROC_INCLUDED               /*  Allow multiple inclusions        */
#define _SFLPROC_INCLUDED

/*  Type definitions                                                         */

#if (defined (WIN32))
typedef struct _PROC_HANDLE
{
    HANDLE process;
    HANDLE in;
    HANDLE out;
    HANDLE err;
    DESCR  *envd;                       /*  Environment data                 */
} PROC_HANDLE;
typedef PROC_HANDLE *PROCESS;           /*  Process ID type                  */
#define NULL_PROCESS NULL               /*    and null process               */
#else
typedef qbyte        PROCESS;           /*  Process ID type                  */
#define NULL_PROCESS 0                  /*    and null process               */
#endif

/*  Global variables                                                         */

extern int process_errno;               /*  Last process exit code           */
extern int process_delay;               /*  Wait for child to start          */

#ifdef __cplusplus
extern "C" {
#endif

PROCESS process_create  (char *file, char *argv [], char *workdir,
                         char *std_in, char *std_out, char *std_err,
                         char *envv [], Bool wait);
int     process_status  (PROCESS process_id);
int     process_kill    (PROCESS process_id);
void    process_close   (PROCESS process_id);
int     process_server  (char *workdir, char *lockfile);

#ifdef __cplusplus
}
#endif

/*  Return values from process_status()                                      */

#define PROCESS_RUNNING         0
#define PROCESS_ENDED_OK        1
#define PROCESS_ENDED_ERROR     2
#define PROCESS_INTERRUPTED     3

#endif
