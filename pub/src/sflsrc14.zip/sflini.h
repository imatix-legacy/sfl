/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflini.h
    Title:      Initialisation file access functions
    Package:    Standard Function Library (SFL)

    Written:    94/01/08  Pieter Hintjens <ph@imatix.com>
    Revised:    96/05/25  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Provides functions to read an initialisation file that follows
                the MS-Windows style, i.e. consists of [Sections] followed by
                keyword = value lines.

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SLFINI_INCLUDED                /*  Allow multiple inclusions        */
#define _SLFINI_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

Bool ini_find_section    (FILE *inifile, char *section, Bool top);
Bool ini_scan_section    (FILE *inifile, char **keyword, char **value);

#ifdef __cplusplus
}
#endif

#endif
