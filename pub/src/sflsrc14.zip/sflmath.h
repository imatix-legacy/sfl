/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflmath.h
    Title:      Mathematic functions
    Package:    Standard Function Library (SFL)

    Written:    96/05/12  Pieter Hintjens <ph@imatix.com>
    Revised:    96/12/04  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Provides miscellaneous mathematical functions, including
                calculation of points within areas.

    Copyright:  Copyright (c) 1991-1996 iMatix  Adapted from NCSA HTTPd.
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLMATH_INCLUDED               /*  Allow multiple inclusions        */
#define _SFLMATH_INCLUDED

/*  Structure declaration                                                    */

typedef struct
  {
    double x;
    double y;
  } FPOINT;

/*  Function prototypes                                                      */

#ifdef __cplusplus
extern "C" {
#endif

int  point_in_rect   (FPOINT *point, FPOINT *coords);
int  point_in_circle (FPOINT *point, FPOINT *coords);
int  point_in_poly   (FPOINT *point, FPOINT *coords, int nb_point);

#ifdef __cplusplus
}
#endif

#endif
