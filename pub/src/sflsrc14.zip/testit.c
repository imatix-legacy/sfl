#include "prelude.h"


void main (int argc, char *argv [])
{
    int string;
    for (string = 0; environ [string]; string++)
        puts (environ [string]);
}
