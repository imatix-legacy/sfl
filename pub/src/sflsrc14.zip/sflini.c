/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflini.c
    Title:      Initialisation file access functions
    Package:    Standard Function Library (SFL)

    Written:    94/01/18  Pieter Hintjens <ph@imatix.com>
    Revised:    96/10/25  Pieter Hintjens <ph@imatix.com>

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sflstr.h"                     /*  String functions                 */
#include "sflfile.h"                    /*  File access functions            */
#include "sflini.h"                     /*  Prototypes for functions         */


/*  Static variables used globally in this source file only                  */

static char
    iniline       [LINE_MAX + 1],       /*  Line from ini file               */
    match_section [LINE_MAX + 1],       /*  Match [section name]             */
    match_keyword [LINE_MAX + 1],       /*  Match keyword =                  */
    match_value   [LINE_MAX + 1];       /*  Match = value                    */



/*  ---------------------------------------------------------------------[<]-
    Function: ini_find_section

    Synopsis:

    Finds a specific section in the ini file.  An ini file contains lines
    as shown below.  The section name can be any mix of upper or lowercase.
    You should open the ini file using file_open before you call this
    function.  If the 'top' argument is TRUE, repositions to the start
    of the file before reading, else reads from the current file offset.
    Returns TRUE if the section was found, and positions on the line that
    follows the section.  Returns FALSE if the section was not found, and
    positions at the end of the file.

    Examples:
    ;   comments like this, or
    #   comments like this if you prefer
    [Section]
        keyword = key_value; comments
        keyword = "key_value"; comments
        ...
    [Section]
        keyword = key_value; comments
        ...
    ---------------------------------------------------------------------[>]-*/

Bool
ini_find_section (FILE *inifile, char *section, Bool top)
{
    ASSERT (inifile != NULL);
    ASSERT (section != NULL);

    if (top)                            /*  Reposition at top if wanted      */
        fseek (inifile, 0, SEEK_SET);

    /*  Read through file until we find what we are looking for              */
    while (file_read (inifile, iniline))
      {
        if (sscanf (iniline, " [%[^]]", match_section) == 1
        &&  lexcmp (match_section, section) == 0)
            return (TRUE);
      }
    return (FALSE);
}


/*  ---------------------------------------------------------------------[<]-
    Function: ini_scan_section

    Synopsis:
    Scans the current section of the ini file, and returns a keyword and
    value if such was found.  Returns the address of these values in the
    supplied arguments.  The addresses point to static values that are
    overwritten with each call.  Returns TRUE when a keyword/value pair
    is found.  Returns FALSE if a new section name or end of file is found.
    In the first case, sets the keyword to the section name; in the second
    case sets the keyword to NULL.  Ignores blank and comment lines, and
    lines that look like junk.  Keyword and section names are returned as
    lower-case; values are returned exactly as specified in the ini file.
    ---------------------------------------------------------------------[>]-*/

Bool
ini_scan_section (FILE *inifile, char **keyword, char **value)
{
    char
        *first;

    /*  Read through file until we find what we are looking for              */
    while (file_read (inifile, iniline))
      {
        first = strskp (iniline);       /*  Skip leading spaces              */
        if (*first == ';' || *first == '#' || *first == 0)
            continue;                   /*  Comment line                     */
        else
        if (sscanf (iniline, " [%[^]]", match_section) == 1)
          {
            *keyword = strlwc (match_section);
            *value   = NULL;
            return (FALSE);             /*  New section name                 */
          }
        else
        if (sscanf (iniline, " %[^=] = \"%[^\"]\"", match_keyword,
                                                    match_value) == 2)
          {
            *keyword = strcrop (strlwc (match_keyword));
            *value   = strcrop (match_value);
            return (TRUE);              /*  Found keyword = value            */
          }
        else
        if (sscanf (iniline, " %[^=] = %[^;#]", match_keyword,
                                                match_value) == 2)
          {
            *keyword = strcrop (strlwc (match_keyword));
            *value   = strcrop (match_value);
            return (TRUE);              /*  Found keyword = value            */
          }
      }
    *keyword = NULL;
    return (FALSE);                     /*  End of file                      */
}
