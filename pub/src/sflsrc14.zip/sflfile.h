/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflfile.h
    Title:      File-access functions
    Package:    Standard Function Library (SFL)

    Written:    92/10/25  Pieter Hintjens <ph@imatix.com>
    Revised:    96/12/13  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Provides functions to read and write files with explicit
                new-line/carriage-return control; to find files on a path;
                to copy files, check files' protection, etc.

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLFILE_INCLUDED               /*  Allow multiple inclusions        */
#define _SFLFILE_INCLUDED


/*  System-specific definitions                                              */

#if (defined (__MSDOS__))
#   define FOPEN_READ_TEXT      "rt"    /*  Under DOS we can be explict      */
#   define FOPEN_READ_BINARY    "rb"    /*    and use 't' or 'b' in fopen    */
#   define FOPEN_WRITE_TEXT     "wt"
#   define FOPEN_WRITE_BINARY   "wb"
#   define FOPEN_APPEND_TEXT    "at"
#   define FOPEN_APPEND_BINARY  "ab"
#elif (defined (__VMS__))
#   define FOPEN_READ_TEXT      "r"     /*  Dec C does not like 't' or 'b'   */
#   define FOPEN_READ_BINARY    "r"
#   define FOPEN_WRITE_TEXT     "w"
#   define FOPEN_WRITE_BINARY   "w"
#   define FOPEN_APPEND_TEXT    "a"
#   define FOPEN_APPEND_BINARY  "a"
#elif (defined (__UNIX__))
#   define FOPEN_READ_TEXT      "rt"    /*  Under UNIX we can be explict     */
#   define FOPEN_READ_BINARY    "rb"    /*    and use 't' or 'b' in fopen    */
#   define FOPEN_WRITE_TEXT     "wt"
#   define FOPEN_WRITE_BINARY   "wb"
#   define FOPEN_APPEND_TEXT    "at"
#   define FOPEN_APPEND_BINARY  "ab"
#elif (defined (__OS2__))
#   define FOPEN_READ_TEXT      "rt"    /*  Under OS/2 we can be explict     */
#   define FOPEN_READ_BINARY    "rb"    /*    and use 't' or 'b' in fopen    */
#   define FOPEN_WRITE_TEXT     "wt"
#   define FOPEN_WRITE_BINARY   "wb"
#   define FOPEN_APPEND_TEXT    "at"
#   define FOPEN_APPEND_BINARY  "ab"
#else
#   error "No definitions for FOPEN constants"
#endif


/*  Function prototypes                                                      */

#ifdef __cplusplus
extern "C" {
#endif

FILE  *file_open           (char *filename, char mode);
FILE  *file_locate         (char *path, char *name, char *ext);
Bool   file_close          (FILE *stream);
Bool   file_read           (FILE *stream, char *string);
char  *file_write          (FILE *stream, char *string);
int    file_copy           (char *dest, char *src, char mode);
char  *file_where          (char mode, char *path, char *name, char *ext);
Bool   file_exists         (char *filename);
Bool   file_cycle          (char *filename);
Bool   safe_to_extend      (char *filename);
int    default_extension   (char *dest, char *src, char *ext);
int    fixed_extension     (char *dest, char *src, char *ext);
char  *strip_extension     (char *filename);
char  *strip_file_path     (char *filename);
Bool   file_is_readable    (char *filename);
Bool   file_is_writeable   (char *filename);
Bool   file_is_executable  (char *filename);
Bool   file_is_directory   (char *filename);
long   get_file_size       (char *filename);
time_t get_file_time       (char *filename);

#ifdef __cplusplus
}
#endif


/*  Symbols, macros                                                          */

#define FILE_NAME_MAX   160             /*  Max size of filename             */
#define FILE_DIR_MAX    64              /*  Max size of directory name       */


/*  External variables                                                       */

extern Bool  file_crlf;                 /*  TRUE or FALSE                    */

#endif
