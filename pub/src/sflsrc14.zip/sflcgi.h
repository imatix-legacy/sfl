/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflcgi.h
    Title:      Common Gateway Interface functions
    Package:    Standard Function Library (SFL)

    Written:    96/05/31  Pieter Hintjens <ph@imatix.com>
    Revised:    96/12/04  Pieter Hintjens <ph@imatix.com>

    Copyright:  Copyright (c) 1991-1996 iMatix

    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLCGI_INCLUDED                /*  Allow multiple inclusions        */
#define _SFLCGI_INCLUDED

/*  Function prototypes                                                      */

#ifdef __cplusplus
extern "C" {
#endif

int cgi_query_to_sym      (char *buffer, SYMTAB *table);
int file_cgi_query_to_sym (FILE *file,   SYMTAB *table);

#ifdef __cplusplus
}
#endif

#endif
