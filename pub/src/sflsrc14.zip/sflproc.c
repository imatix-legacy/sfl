/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflproc.c
    Title:      Process control functions
    Package:    Standard Function Library (SFL)

    Written:    96/09/09  Pieter Hintjens <ph@imatix.com>
    Revised:    97/01/02  Ewen McNeill <ewen@naos.co.nz>

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sfltok.h"                     /*  Token-handling functions         */
#include "sflmem.h"                     /*  Memory-handling functions        */
#include "sflstr.h"                     /*  String-handling functions        */
#include "sflfile.h"                    /*  File access functions            */
#include "sflproc.h"                    /*  Prototypes for functions         */

/*  Global variables                                                         */

int process_errno = 0;                  /*  Last process exit code           */
int process_delay = 1000;               /*  Wait for child to start, msecs   */

#if (!defined (WIN32))
#define HANDLE    int                   /*  Windows uses HANDLE for files    */
#endif


/*  Function prototypes                                                      */

static void   new_handler    (int sigvalue);
static HANDLE redirect_io    (char *device, int fileno, int err_pipe,
                              Bool read_only);


/*  ---------------------------------------------------------------------[<]-
    Function: process_create

    Synopsis: Creates a subprocess and returns a PROCESS identifying the new
    process.  Optionally directs standard input, output, and error streams
    to specified devices.  The caller can also specify environment symbols
    that the subprocess can access.  Accepts these arguments:
    <Table>
    filename    File to execute; if not fully specified, searches PATH.
    argv_[]     List of arguments; argv [0] is filename; ends in a NULL.
    workdir     Working directory; if NULL, remains in current directory.
    std_in      Device to use for standard input; NULL = no redirection.
    std_out     Device to use for standard output; NULL = no redirection.
    std_err     Device to use for standard error; NULL = no redirection.
    envs_[]     List of environment symbols to define, or NULL.
    </Table>
    If argv is NULL, parses the filename argument into words delimited by
    whitespace and builds the necessary argv table automatically.  Use this
    feature to execute a command with arguments, specified as one string.
    The envv list consists of strings in the form "name=value", ending in a
    NULL pointer.  If the envv argument is null, the environment of the
    current process is passed.  Otherwise the envv environment is used.
    If the process is started correctly, this function will sleep for
    'process_delay' milliseconds.  If the child command detects an error
    at startup, it may exit with an error status.  The sleep allows this
    error to be collected by calling process_status() after this call.  If
    process_delay is 0, any child error is ignored.
    Returns child process id, or 0 if there was an error.
    Known bugs: when parsing filename argument into words, does not handle
    quotes in any special way; "this text" is 2 words, '"this' and 'text"'.
    ---------------------------------------------------------------------[>]-*/

PROCESS
process_create (
    char *filename,                     /*  Name of file to execute          */
    char *argv [],                      /*  Arguments for process, or NULL   */
    char *workdir,                      /*  Working directory, or NULL       */
    char *std_in,                       /*  Stdin device, or NULL            */
    char *std_out,                      /*  Stdout device, or NULL           */
    char *std_err,                      /*  Stderr device, or NULL           */
    char *envv [],                      /*  Environment variables, or NULL   */
    Bool  wait                          /*  Wait for process to end          */
)
{
#if (defined (__UNIX__) || defined (__OS2__))
    pid_t
        fork_result;                    /*  Result from fork()               */
    int
        pipe_handle [2],                /*  Parent-to-child pipe             */
        pipe_readsize,                  /*  Amount of data read from pipe    */
        pipe_data;                      /*  Data read from pipe              */
#   if (defined (__UNIX__))
    struct itimerval
        timeout;                        /*  Wait for response from child     */
#   elif (defined (__OS2__))
    unsigned int
        timeout;                        /*  Wait for response from child     */
#   else
#       error process_create(): timeout not declared
#   endif
    struct sigaction
        old_handler;                    /*  Old handler for SIGALRM          */
    char
        *full_filename;                 /*  File to execute, with path       */

    /*  Create pipe for feedback from child to parent; quit if this fails    */
    if (pipe (pipe_handle))
        return (0);

    /*  Create subprocess - this returns 0 if we are the child, the pid if   */
    /*  we are the parent, or -1 if there was an error (not enough memory).  */
    fork_result = fork ();

    if (fork_result < 0)                /*  < 0 is an error                  */
        return (0);                     /*  Could not fork                   */
    else
    if (fork_result > 0)                /*  > 0 is the parent process        */
      {
        /*  --- PARENT PROCESS HANDLING ------------------------------------ */
        /*  If the child process has a problem with the exec() call, it      */
        /*  sends us an errno value across the pipe.  If the exec() call     */
        /*  works okay, we get no feedback across the pipe.  We wait for a   */
        /*  small time (number of msecs specified by process_delay).  If     */
        /*  nothing comes across the pipe, we assume everything went okay.   */
        /*  The FD_CLOEXEC setting *should* cause the child pipe to close    */
        /*  after exec() but this does not seem to work; the read() still    */
        /*  blocks.  Bummer.                                                 */

        if (process_delay > 0)
          {
#   if (defined (__UNIX__))
            timeout.it_interval.tv_sec  = 0;
            timeout.it_interval.tv_usec = 0;
            timeout.it_value.tv_sec     =  process_delay / 1000;
            timeout.it_value.tv_usec    = (process_delay % 1000) * 1000;
#   elif (defined (__OS2__))
            /*  Since we use alarm() for our timeout, we can only time to    */
            /*  the nearest second -- EDM.                                   */
            timeout = process_delay / 100;
#   endif
            /*  Save old signal handler to be polite to the calling program  */
            /*  then redirect the SIGALRM signal to our own (empty) handler  */
            sigaction (SIGALRM, NULL, &old_handler);
            signal    (SIGALRM, new_handler);

#   if (defined (__UNIX__))
            setitimer (ITIMER_REAL, &timeout, 0);
#   elif (defined (__OS2__))
            (void) alarm (timeout);
#   endif

            /*  Now read on the pipe until data arrives or the alarm goes    */
            pipe_readsize = read (pipe_handle [0], &pipe_data, sizeof (errno));

            /*  Restore old signal handler                                   */
            sigaction (SIGALRM, &old_handler, NULL);
          }
        else
            pipe_readsize = 0;

        if (pipe_readsize == -1)
          {
            if (errno == EBADF || errno == EINTR)
              {
                /*  Normal - SIGALRM arrived or FD_CLOEXEC worked :)         */
                if (wait)
                    waitpid (fork_result, 0, 0);
                return ((PROCESS) fork_result);
              }
            else
                return (0);             /*  Error on read()                  */
          }
        else
        /*  We come here if process_delay was zero, or FD_CLOEXEC did its    */
        /*  job and the pipe was closed by the child process.                */
        if (pipe_readsize == 0)
          {
            if (wait)
                waitpid (fork_result, 0, 0);
            return ((PROCESS) fork_result);
          }
        else
          {
            /*  We read data from the pipe - this is an error feedback from  */
            /*  the child - i.e. file not found, or a permission problem.    */
            close (pipe_handle [0]);    /*  Close the pipe                   */
            close (pipe_handle [1]);
            errno = pipe_data;          /*    and stuff the errno            */
            return (0);
          }
      }
    /*  --- CHILD PROCESS HANDLING ----------------------------------------- */
    /*  Prepare the process environment and execute the file                 */

    /*  If argv[] array was not supplied, build it now from filename         */
    if (!argv)
      {
        argv = tok_split (filename);    /*  argv [0] = name,...              */
        filename = argv [0];            /*  Get rid of following arguments   */
      }

    /*  Find file on path, make sure it is executable                        */
    if (strchr (filename, '/') == NULL)
        full_filename = file_where ('r', "PATH", filename, NULL);
    else
        full_filename = file_where ('r',  NULL,  filename, NULL);

    if (full_filename == NULL)
      {
        errno = ENOENT;                 /*  No such file                     */
        write (pipe_handle [1], &errno, sizeof (errno));
        exit (EXIT_FAILURE);            /*  Kill the child process           */
      }
    if (!file_is_executable (full_filename))
      {
        errno = EACCES;                 /*  No permission to access file     */
        write (pipe_handle [1], &errno, sizeof (errno));
        exit (EXIT_FAILURE);            /*  Kill the child process           */
      }

    /*  If requested, change to working directory                            */
    if (workdir)
        chdir (workdir);

    /*  If requested, close stdin, stdout, stderr, and redirect them         */
    redirect_io (std_in,  STDIN_FILENO,  pipe_handle [1], TRUE);
    redirect_io (std_out, STDOUT_FILENO, pipe_handle [1], FALSE);
    redirect_io (std_err, STDERR_FILENO, pipe_handle [1], FALSE);

    /*  Tell the system to close the pipe when we've done the exec()         */
    fcntl (pipe_handle [0], F_SETFD, FD_CLOEXEC);
    fcntl (pipe_handle [1], F_SETFD, FD_CLOEXEC);

    /*  Execute the program - normally this call does not return, as it      */
    /*  replaces the current process image by the new one.  If we ever do    */
    /*  return, it is because there was an error.                            */
    if (envv)                           /*  If caller provided envv, use it  */
        execve (full_filename, argv, envv);
    else
        execv  (full_filename, argv);   /*  Otherwise use current values     */

    write (pipe_handle [1], &errno, sizeof (errno));
    exit (EXIT_FAILURE);                /*  Kill the child process           */

#elif (defined (WIN32))
    PROCESS
        process;                        /*  Our created process handle       */
    STARTUPINFO
        newinfo = {0},                  /*  Specification for new process    */
        curinfo;                        /*  Specification of cur process     */
    PROCESS_INFORMATION
        procinfo;                       /*  Information about created proc   */
    DWORD
        dwCreateFlags = NORMAL_PRIORITY_CLASS | DETACHED_PROCESS;

    process = (PROCESS) mem_alloc (sizeof (PROC_HANDLE));
    process-> process = NULL;
    process-> in   = redirect_io (std_in,  0, 0, TRUE);
    process-> out  = redirect_io (std_out, 0, 0, FALSE);
    process-> err  = redirect_io (std_err, 0, 0, FALSE);

    /*  Convert environment to a Windows-type packed block of strings        */
    /*  Use supplied environment, or parent environment if necessary.        */
    process-> envd = strt2descr (envv? envv: environ);

    GetStartupInfo (&curinfo);
    newinfo.cb          = sizeof (newinfo);
    newinfo.dwFlags     = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
    newinfo.wShowWindow = SW_HIDE;
    newinfo.hStdInput   = process-> in?  process-> in:  curinfo.hStdInput;
    newinfo.hStdOutput  = process-> out? process-> out: curinfo.hStdOutput;
    newinfo.hStdError   = process-> err? process-> err: curinfo.hStdError;
    newinfo.lpTitle     = NULL;

    /*  CreateProcess returns errors sometimes, even when the process was    */
    /*  started correctly.  The cause is not evident.  For now: we detect    */
    /*  an error by checking the value of procinfo.hProcess after the call.  */
    procinfo.hProcess   = NULL;

    CreateProcess (
        NULL,                           /*  Name of executable module        */
        filename,                       /*  Command line string              */
        NULL,                           /*  Process security attributes      */
        NULL,                           /*  Thread security attributes       */
        TRUE,                           /*  Handle inheritance flag          */
        dwCreateFlags,                  /*  Creation flags                   */
        process-> envd-> data,          /*  New environment block            */
        workdir,                        /*  Current directory name           */
        &newinfo,                       /*  STARTUPINFO                      */
        &procinfo);                     /*  PROCESS_INFORMATION              */

    if (procinfo.hProcess == NULL)
      {
        process_close (process);
        return (NULL);
      }

    /*  Release our hold on the thread                                       */
    CloseHandle (procinfo.hThread);
    process-> process = procinfo.hProcess;

    /*  Wait for the process to finish or be cancelled                       */
    if (wait && WaitForSingleObject (procinfo.hProcess, INFINITE)
                                                == WAIT_OBJECT_0)
      {
        /*  Close our hold on it                                             */
        process_close (process);
        procinfo.hProcess = (void *) -1;
      }
    return (process);
#else
    return ((PROCESS) 0);               /*  Not supported on this system     */
#endif
}


/*  --------------------------------------------------------------------------
 *  new_handler -- local
 *
 *  Handles a signal (we ignore it).
 */

local
new_handler (int sigvalue)
{
    ASSERT (sigvalue == SIGALRM);
}


/*  --------------------------------------------------------------------------
 *  redirect_io -- local
 *
 *  Redirects the specified file number to the specified device, if the
 *  device name is not null or empty.  If the redirection fails, leaves
 *  the original device unchanged, writes the errno to the error pipe and
 *  exits the current process.  Returns the file handle, or 0 if the
 *  device name was empty or NULL.
 */

static HANDLE
redirect_io (char *device, int fileno, int err_pipe, Bool read_only)
{
    HANDLE
        file_handle = 0;                /*  Opened file handle               */

    /*  If device name is not null, and not empty, redirect it               */
    if (device && *device)
      {
#if (defined (__UNIX__) || defined (__OS2__))
        /*  Open experimentally, to see if we have access to the device      */
        if (read_only)
            file_handle = open (device, O_RDONLY);
        else
            file_handle = open (device, O_RDWR | O_CREAT | O_TRUNC,
                                        S_IREAD | S_IWRITE);
        if (file_handle == -1)
          {
            write (err_pipe, &errno, sizeof (errno));
            exit (EXIT_FAILURE);        /*  Kill the child process           */
          }
        else
          {
            /*  Okay, now close both devices and reallocate the original     */
            close (file_handle);
            close (fileno);
            if (read_only)
                file_handle = open (device, O_RDONLY);
            else
                file_handle = open (device, O_RDWR | O_CREAT | O_TRUNC,
                                            S_IREAD | S_IWRITE);
            /*  New file handle must be same as old one                      */
            ASSERT (file_handle == fileno);
          }
#elif (defined (WIN32))
        SECURITY_ATTRIBUTES
            g_sa = { sizeof (SECURITY_ATTRIBUTES), NULL, TRUE };

        if (read_only)
            file_handle = CreateFile (device, GENERIC_READ,
                                      FILE_SHARE_READ, &g_sa, OPEN_ALWAYS,
                                      FILE_ATTRIBUTE_NORMAL, NULL);
        else
            file_handle = CreateFile (device, GENERIC_READ | GENERIC_WRITE,
                                      FILE_SHARE_WRITE, &g_sa, CREATE_ALWAYS,
                                      FILE_ATTRIBUTE_NORMAL, NULL);
#endif
      }
    return (file_handle);
}


/*  ---------------------------------------------------------------------[<]-
    Function: process_status

    Synopsis: Returns status of process specified by process ID.  Returns
    one of these values, or -1 if there was an error:
    <Table>
    PROCESS_RUNNING       Process is still running.
    PROCESS_ENDED_OK      Process ended normally.
    PROCESS_ENDED_ERROR   Process ended with an error status.
    PROCESS_INTERRUPTED   Process was interrupted (killed).
    </Table>
    In the case of PROCESS_ENDED_ERROR, the global variable process_errno is
    set to the exit code returned by the process.
    ---------------------------------------------------------------------[>]-*/

int
process_status (PROCESS process_id)
{
#if (defined (__UNIX__))
    int
        status;
    pid_t
        return_pid;

    /*  waitpid() returns 0 if the child process is still running, or the    */
    /*  process id if it stopped.  It can also return -1 in case of error.   */
    /*  No other return value is possible.                                   */
    return_pid = waitpid (process_id, &status, WNOHANG | WUNTRACED);
    if (return_pid == 0)
        return (PROCESS_RUNNING);
    else
    if (return_pid == process_id)
      {
        if (WIFEXITED (status))        /*  Program called exit()             */
          {
            process_errno = WEXITSTATUS (status);
            if (process_errno)         /*  Treat exit (0) as normal end      */
                return (PROCESS_ENDED_ERROR);
            else
                return (PROCESS_ENDED_OK);
          }
        else
        if (WIFSIGNALED (status))       /*  Process was interrupted          */
            return (PROCESS_INTERRUPTED);
        else
            return (PROCESS_ENDED_OK);
      }
    else
        return (-1);
#elif (defined (WIN32))
    DWORD
         status;

    status = WaitForSingleObject (process_id-> process, 0);

    if (status == WAIT_TIMEOUT)
        return (PROCESS_RUNNING);
    else
    if (status == WAIT_OBJECT_0)
        return (PROCESS_ENDED_OK);
    else
    if (status == WAIT_ABANDONED)
        return (PROCESS_ENDED_ERROR);
    else
        return (-1);
#else
    return (-1);                        /*  Not supported on this system     */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: process_kill

    Synopsis: Ends a process specified by a process id.  The current process
    must have the appropriate authority to stop the specified process.
    Returns zero if the process was killed, -1 if there was an error.
    ---------------------------------------------------------------------[>]-*/

int
process_kill (PROCESS process_id)
{
#if (defined (__UNIX__))
    if (kill (process_id, SIGKILL))
        return (-1);

    while (process_status (process_id) == PROCESS_RUNNING);
    return (0);

#elif (defined (WIN32))
    Bool
        rc = TerminateProcess (process_id-> process, 1);
    if (rc)
        process_close (process_id);
    return (rc? 0: -1);
#else
    return (-1);                        /*  Not supported on this system     */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: process_close

    Synopsis: You should call this function when a process has ended
    normally, if you did not specify the wait option when calling the
    process_create() function.  On some systems, each created process
    uses some memory.  process_close() guarantees that this memory is
    correctly freed.  Does nothing if the process handle is NULL.
    ---------------------------------------------------------------------[>]-*/

void
process_close (PROCESS process)
{
#if (defined (WIN32))
    if (process)
      {
        if (process-> process)
            CloseHandle (process-> process);
        if (process-> in)
            CloseHandle (process-> in);
        if (process-> out)
            CloseHandle (process-> out);
        if (process-> err)
            CloseHandle (process-> err);

        mem_free (process-> envd);
        mem_free (process);
      }
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: process_server

    Synopsis: Converts the process from an interactive foreground process
    into a background process.  The precise effect of this depends on the
    system.  On UNIX, does this:
    <LIST>
    Switches the process to run as a background job, under init;
    closes all open files;
    moves to a safe, known working directory, if required;
    sets the umask for new files;
    opens stdin, stdout, and stderr to the null device;
    enforces exclusive execution through a lock file, if required;
    logs the process id in the lock file;
    ignores the hangup unwanted signals.
    </LIST>
    On other systems, may do nothing.
    ---------------------------------------------------------------------[>]-*/

int
process_server (
    char *workdir,                      /*  Where server runs, or NULL/""    */
    char *lockfile)                     /*  For exclusive execution          */
{
#if (defined (__UNIX__))
    int
        fork_result,
        file_handle;
    char
        pid_buffer [10];
    struct flock
        lock_file;                      /*  flock() argument block           */

    /*  We recreate our process as a child of init.  The process continues   */
    /*  to exit in the background.  UNIX calls wait() for all children of    */
    /*  the init process, so the server will exit cleanly.                   */

    fork_result = fork ();
    if (fork_result < 0)                /*  < 0 is an error                  */
        return (-1);                    /*  Could not fork                   */
    else
    if (fork_result > 0)                /*  > 0 is the parent process        */
        exit (EXIT_SUCCESS);            /*  End parent process               */

    /*  We close all open file descriptors that may have been inherited      */
    /*  from the parent process.  This is to reduce the resources we use.    */

    for (file_handle = getdtablesize () - 1; file_handle >= 0; file_handle--)
        close (file_handle);            /*  Ignore errors                    */

    /*  We move to a safe and known directory, which is supplied as an       */
    /*  argument to this function (or not, if workdir is NULL or empty).     */

    if (workdir && strused (workdir))
        chdir (workdir);

    /*  We set the umask so that new files are given mode 750 octal          */

    umask (027);                        /*  Complement of 0750               */

    /*  We set standard input and output to the null device so that any      */
    /*  functions that assume that these files are open can still work.      */

    file_handle = open ("/dev/null", O_RDWR);    /*  stdin = handle 0        */
    dup (file_handle);                           /*  stdout = handle 1       */
    dup (file_handle);                           /*  stderr = handle 2       */

    /*  We enforce a lock on the lockfile, if specified, so that only one    */
    /*  copy of the server can run at once.  We return -1 if the lock fails. */
    /*  This locking code might be better isolated into a separate package,  */
    /*  since it is not very portable between unices.                        */

    if (lockfile && strused (lockfile))
      {
        file_handle = open (lockfile, O_RDWR | O_CREAT, 0640);
        if (file_handle < 0)
            return (-1);                /*  We could not open lock file      */
        else
          {
            lock_file.l_type = F_WRLCK;
            if (fcntl (file_handle, F_SETLK, &lock_file))
                return (-1);            /*  We could not obtain a lock       */
          }
        /*  We record the server's process id in the lock file               */
        sprintf (pid_buffer, "%6d\n", getpid ());
        write   (file_handle, pid_buffer, strlen (pid_buffer));
      }

    /*  We ignore any hangup signal from the controlling TTY                 */
    signal (SIGHUP, SIG_IGN);

    return (0);                         /*  Initialisation completed ok      */
#else
    return (0);                         /*  Nothing to do on this system     */
#endif
}
