/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflcgi.c
    Title:      Common Gateway Interface functions
    Package:    Standard Function Library (SFL)

    Written:    96/05/31  Pieter Hintjens <ph@imatix.com>
    Revised:    96/12/04  Pieter Hintjens <ph@imatix.com>

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sflstr.h"                     /*  String functions                 */
#include "sflsymb.h"                    /*  Symbol functions                 */
#include "sflconv.h"                    /*  Convertion functions             */
#include "sflmem.h"                     /*  Memory functions                 */
#include "sflcgi.h"                     /*  Prototypes for functions         */


/*  ---------------------------------------------------------------------[<]-
    Function: cgi_query_to_sym

    Synopsis: Parse cgi query string and add variable name and value into
    a symbol table.  Returns the number of variables added.
    ---------------------------------------------------------------------[>]-*/

int
cgi_query_to_sym (char *buffer, SYMTAB *table)
{
    char
        *variable = NULL,           /*  Variable separator pointer       */
        *copy,
        *equal;
    int
        nb_variable = 0;

    ASSERT (buffer);
    ASSERT (table);

    copy = mem_strdup (buffer);
    if (copy == NULL)
        return (0);

    strconvch (copy, '+', ' ');
    strconvch (copy, '\r', '\0');
    strconvch (copy, '\n', '\0');

    variable = strtok (copy, "&");
    if (variable)
      {
        while (variable)
          {
            equal = strchr (variable, '=');
            if (equal)
              {
                *equal++ = '\0';
                sym_assume_symbol (table, variable, equal);
                nb_variable++;
              }
            variable = strtok (NULL, "&");
          }
      }
    else
      {
        equal = strchr (copy, '=');
        if (equal)
          {
            *equal++ = '\0';
            sym_assume_symbol (table, copy, equal);
            nb_variable++;
          }
      }
    mem_free (copy);
    return (nb_variable);
}


/*  ---------------------------------------------------------------------[<]-
    Function: file_cgi_query_to_sym

    Synopsis: Parse cgi query string from a file and add variable name and
    value into a symbol table.  Returns the number of variables added.
    ---------------------------------------------------------------------[>]-*/

int
file_cgi_query_to_sym (FILE *file, SYMTAB *table)
{
    long
        length;
    char
        *buffer;
    int
        read_size,
        nb_variable = 0;

    ASSERT (file);
    ASSERT (table);

    fseek (file, 0, SEEK_END);
    length = ftell (file);
    fseek (file, 0, SEEK_SET);
    if (length > 0)
      {
        buffer = mem_alloc ((size_t) length + 1);
        if (buffer)
          {
            read_size = fread (buffer, 1, (size_t) length, file);
            if (read_size > 0)
                nb_variable = cgi_query_to_sym (buffer, table);
            mem_free (buffer);
          }
      }
    return (nb_variable);
}
