/*  ----------------------------------------------------------------<Prolog>-
    Name:       testsym.c
    Title:      Test program for symbol-table functions
    Package:    Standard Function Library (SFL)

    Written:    96/04/24  Pieter Hintjens <ph@imatix.com>
    Revised:    96/07/14

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "sfl.h"

static Bool
dump_symbol (SYMBOL *symbol, ...)
{
    printf ("%s = %s\n", symbol-> name, symbol-> value);
    return (TRUE);
}

int main (int argc, char *argv [])
{
    SYMTAB *
        table;

    table = sym_create_table ();
    sym_create_symbol (table, "Symbol 1", "value 1");
    sym_create_symbol (table, "Symbol 2", "value 2");
    sym_exec_all (table, dump_symbol);
    sym_delete_table (table);

    return (EXIT_SUCCESS);
}
