/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflsrt.h
    Title:      String-handling functions
    Package:    Standard Function Library (SFL)

    Written:    92/10/25  Pieter Hintjens <ph@imatix.com>
    Revised:    96/10/28  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Provides various string-handling functions.  Some of these
                functions are available on some but not all platforms; others
                are useful tools for string handling.

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLSTR_INCLUDED                /*  Allow multiple inclusions        */
#define _SFLSTR_INCLUDED


/*  Function prototypes                                                      */

#ifdef __cplusplus
extern "C" {
#endif

char   *strdupl            (char *string);
char  **strfree            (char **string);
char   *strskp             (char *string);
char   *strcset            (char *string, char ch);
char   *strpad             (char *string, char ch, int length);
char   *strlwc             (char *string);
char   *strupc             (char *string);
char   *strcrop            (char *string);
char   *stropen            (char *string, Bool align);
char   *strclose           (char *string, Bool align);
int     strmatch           (char *string1, char *string2);
qbyte   strhash            (char *string);
char   *xstrcat            (char *dest, char *src, ...);
char   *xstrcpy            (char *dest, char *src, ...);
int     lexcmp             (char *string1, char *string2);
char   *soundex            (char *string);
DESCR  *strt2descr         (char **strings);
char  **descr2strt         (DESCR *descr);
void    strtfree           (char **strings);
Bool    strescape          (char *string);
Bool    strunescape        (char *string);
char   *strconvch          (char *string, char from, char to);

#ifdef __cplusplus
}
#endif


#endif
