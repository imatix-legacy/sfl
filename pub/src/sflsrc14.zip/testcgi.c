/*  ----------------------------------------------------------------<Prolog>-
    Name:       testcgi.c
    Title:      CGI test program
    Package:    Standard Function Library (SFL)

    Written:    96/10/01  Pieter Hintjens <ph@imatix.com>
    Revised:    96/12/04  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Generates an HTML test page containing the arguments passed
                to the CGI process.

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "sfl.h"                        /*  SFL functions                    */

static Bool dump_symbol (SYMBOL *symbol, ...);

int
main (int argc, char *argv [])
{
    SYMTAB
        *symbols;
    int
        index;

    printf ("HTTP/1.0 200 Ok\n");
    printf ("Content-Type: text/html\n\n");
    printf ("<HTML><HEAD><TITLE>CGI Test Program</TITLE></HEAD>\n");
    printf ("<BODY>\n");
    printf ("<H1>CGI Test Program</H1>\n");

    /*  Print Argument variables                                             */
    if (argc > 1)
      {
        printf ("<H2>Arguments To Testcgi</H2>\n");
        printf ("<PRE>\n");
        for (index = 1; index < argc; index++)
            printf ("<B>Argument %d </B>: %s\n", index, argv [index]);
        printf ("</PRE>\n");
      }

    /*  Print STDIN variables                                                */
    if (getenv ("HTTP_CONTENT_LENGTH"))
      {
        symbols = sym_create_table ();
        if (symbols)
          {
            if (file_cgi_query_to_sym (stdin, symbols) > 0)
              {
                printf ("<H2>Input CGI Variables</H2>\n");
                printf ("<PRE>\n");
                sym_exec_all (symbols, dump_symbol);
                printf ("</PRE>\n");
              }
            sym_delete_table (symbols);
          }
      }

    /*  Print environment variables                                          */
    symbols = env2symb ();
    if (symbols)
      {
        printf ("<H2>Environment Variables</H2>\n");
        printf ("<PRE>\n");
        sym_exec_all (symbols, dump_symbol);
        sym_delete_table (symbols);
        printf ("</PRE>\n");
      }
    printf ("</BODY></HTML>\n");
    return (0);
}


/*  This function is invoked by sym_exec_all() to process each item in
    the symbol table.  It always returns TRUE to keep sym_exec_all() going.  */

static Bool
dump_symbol (SYMBOL *symbol, ...)
{
    printf ("<B>%-20s</B> = %s\n", symbol-> name, symbol-> value);
    return (TRUE);
}
