/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflenv.h
    Title:      Environment variable functions
    Package:    Standard Function Library (SFL)

    Written:    96/05/14  Pieter Hintjens <ph@imatix.com>
    Revised:    96/10/26  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Provides functions to read environment variables (also called
                shell variables or logical variables.)  Provides translation
                into numeric and Boolean values.  Provides functions to work
                with the environment block.

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLENV_INCLUDED                /*  Allow multiple inclusions        */
#define _SFLENV_INCLUDED


/*  Function prototypes                                                      */

#ifdef __cplusplus
extern "C" {
#endif

char    *env_get_string   (char *name, char *default_value);
long     env_get_number   (char *name, long default_value);
Bool     env_get_boolean  (char *name, Bool default_value);
DESCR   *env2descr        (void);
char   **descr2env        (DESCR *descr);
SYMTAB  *env2symb         (void);
char   **symb2env         (SYMTAB *symtab);

#ifdef __cplusplus
}
#endif

#endif
