/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflmem.h
    Title:      Memory allocation functions
    Package:    Standard Function Library (SFL)

    Written:    96/06/08  Pieter Hintjens <ph@imatix.com>
    Revised:    96/06/19  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Encapsulated memory allocation functions.  Based on an
                article by Jim Schimandle in DDJ August 1990.  Provides
                'safe' versions of malloc(), realloc(), free(), and strdup().
                These functions protect the programmer from errors in calling
                memory allocation/free routines.   When these calls are used,
                the allocation routines in this module add a data structure
                to the top of allocated memory blocks which tags them as legal
                memory blocks.  When the free routine is called, the memory
                block to be freed is checked for legality tag.  If the block
                is not legal, the memory list is dumped to stderr and the
                program is terminated.  Some of these functions are called
                through macros, which add the filename and line number of the
                call, for tracing.

    Copyright:  Copyright (c) 1991-96 iMatix, parts copyright (c) DDJ 1990.
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _SFLMEM_INCLUDED                /*  Allow multiple inclusions        */
#define _SFLMEM_INCLUDED


/*  Function prototypes                                                      */

#ifdef __cplusplus
extern "C" {
#endif

void  *_mem_alloc   (size_t size, char *file, word line);
void  *_mem_realloc (void *block, size_t size, char *file, word line);
void   _mem_free    (void *block, char *file, word line);
char  *_mem_strdup  (char *string, char *file, word line);
char **_mem_strfree (char **string, char *file, word line);
void   _mem_assert  (char *file, word line);
long    mem_used    (void);
long    mem_allocs  (void);
long    mem_frees   (void);
void    mem_display (FILE *save_to);

#ifdef __cplusplus
}
#endif

/*  Define macros to simplify calls to these functions                      */

#define mem_alloc(size)        _mem_alloc   ((size), __FILE__, __LINE__)
#define mem_realloc(ptr,size)  _mem_realloc ((ptr), (size), __FILE__, __LINE__)
#define mem_free(ptr)          _mem_free    ((ptr), __FILE__, __LINE__)
#define mem_strdup(str)        _mem_strdup  ((str), __FILE__, __LINE__)
#define mem_strfree(pstr)      _mem_strfree ((pstr), __FILE__, __LINE__)
#define mem_assert()           _mem_assert  (__FILE__, __LINE__)

/*  Global variables                                                         */

extern int mem_trace;

#endif
