/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflenv.c
    Title:      String token manipulation functions.
    Package:    Standard Function Library (SFL)

    Written:    96/09/10  Pieter Hintjens <ph@imatix.com>
    Revised:    96/09/23  Pieter Hintjens <ph@imatix.com>

    Copyright:  Copyright (c) 1991-1996 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sflstr.h"                     /*  Conversion functions             */
#include "sflmem.h"                     /*  Memory allocation functions      */
#include "sfltok.h"                     /*  Prototypes for functions         */


/*  ---------------------------------------------------------------------[<]-
    Function: tok_split

    Synopsis: Accepts a string and breaks it into words, delimited by white
    space (spaces, tabs, newlines).  Returns an array of strings which ends
    in a NULL string.  If the string is empty or NULL, returns an array
    containing a single NULL value.  The array is allocated dynamically by
    this function, and you must call tok_free() to release it when you have
    finished.  Returns NULL if there was insufficient memory to complete the
    split operation.
    ---------------------------------------------------------------------[>]-*/

char **
tok_split (char *string)
{
    char
        *buffer,
        *bufptr,
        **token_list,                   /*  Returned token list              */
        last_char = '\0';               /*  Last character parsed            */
    int
        word_count = 0,                 /*  Number of words in string        */
        word_nbr;

    /*  Allocate space for work string, up to the size of the input string   */
    if ((buffer = mem_alloc (strlen (string) + 1)) == NULL)
        return (NULL);

    /*  Now copy string and eliminate whitespace                             */
    bufptr = buffer;                    /*  Move to start of target buffer   */
    if (string)                         /*  Allow string to be NULL          */
      {
        while (*string)                 /*  Copy entire string               */
            if (isspace (*string))      /*  Collapse whitespace to           */
              {                         /*    a single null byte             */
                word_count++;           /*    unless at the start            */
                while (isspace (*string))
                    string++;
                if (bufptr > buffer)
                    last_char = *bufptr++ = '\0';
              }
            else
                last_char = *bufptr++ = *string++;
      }
    /*  Count last word if it was not terminated in a white space            */
    if (last_char > 0)
        word_count++;   

    *bufptr = '\0';                     /*  End with final NULL              */

    /*  The token list starts with a pointer to the buffer, then has one     */
    /*  pointer to each string in the buffer.  It ends with a null pointer.  */
    /*  We return the address of the first string pointer, i.e. the caller   */
    /*  does not see the pointer to the buffer.  We can thus get away with   */
    /*  just two allocs; one for the buffer and one for the token list.     */
    token_list = mem_alloc (sizeof (char *) * (word_count + 2));

    token_list [0] = buffer;            /*  Store buffer address             */
    token_list++;                       /*    and bump starting address      */

    bufptr = buffer;
    for (word_nbr = 0; word_nbr < word_count; word_nbr++)
      {
        token_list [word_nbr] = bufptr;
        bufptr += strlen (bufptr) + 1;
      }
    token_list [word_count] = NULL;     /*  Store final null pointer         */
    return (token_list);
}


/*  ---------------------------------------------------------------------[<]-
    Function: tok_free

    Synopsis: Frees the memory allocated by a tok_split() call.  You should
    call this function for each call to tok_split(), to avoid memory leaks.
    Do not try to free the allocated memory yourself, as the structure of a
    token list is not documented and may change over time.
    ---------------------------------------------------------------------[>]-*/

void
tok_free (char **token_list)
{
    token_list--;                       /*  Back-up to get right address     */
    mem_free (token_list [0]);          /*  Free buffer                      */
    mem_free (token_list);              /*    and free token list            */
}
