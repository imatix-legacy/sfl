/*  ----------------------------------------------------------------<Prolog>-
    Name:       sflsock.c
    Title:      TCP/IP, UDP/IP socket functions
    Package:    Standard Function Library (SFL)

    Written:    96/02/03  Pieter Hintjens <ph@imatix.com>
    Revised:    97/01/02  Ewen McNeill <ewen@naos.co.nz>

    Copyright:  Copyright (c) 1991-1997 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sflsock.h"                    /*  Prototypes for functions         */

/*  Implementation notes
 *
 *  These functions work on 16-bit Windows, 32-bit Windows, 32-bit UNIX,
 *  64-bit UNIX, Digital OpenVMS.  The size of a socket handle varies from
 *  16 bits to 64 bits.  All native socket functions define a socket handle
 *  as 'int'.  However, we need a fixed-length external representation.  So,
 *  we define a type, 'sock_t', which is a qbyte (32 bits).  Outside this
 *  package, sockets are always a 'sock_t'.  Internally, we always use an
 *  (SOCKET) cast when passing s sock_t to a system function like connect().
 */

/*  Global variables                                                         */

int
    ip_portbase = 0;                    /*  Base for created services        */
Bool
    ip_nonblock = TRUE;                 /*  Create non-blocking sockets      */

/*  The connect_error_value holds the last recorded error cause after a      */
/*  connection attempt.                                                      */

static int
    connect_error_value = 0;
char
    *connect_errlist [] = {             /*  Corresponding error messages     */
        "No errors",
        "System does not support sockets",
        "Host is not known",
        "Service or port not known",
        "Protocol not known",
        "Connection failed on socket()",
        "Connection failed on connect()",
        "Connection failed on bind()",
        "Connection failed on listen()"
    };

/*  Internal functions used to create passive and active connections         */

#if (defined (DOES_SOCKETS))
static void   prepare_socket (sock_t handle);
#if (defined (__WINDOWS__))
static int    win_error      (int rc);
#endif
#endif


/*  ---------------------------------------------------------------------[<]-
    Function: sock_init

    Synopsis: Initialise the internet protocol.  On most systems this is a
    null call.  On some systems this loads dynamic libraries.  Returns 0
    0 if everything was okay, else returns SOCKET_ERROR.  You should call
    sock_term() when your program ends.
    ---------------------------------------------------------------------[>]-*/

int
sock_init (void)
{
#if (defined (__WINDOWS__))
    WORD
        wVersionRequested;              /*  We really want Winsock 1.1       */
    WSADATA
        wsaData;

    wVersionRequested = 0x0101;         /*  ... but we'll take 1.1           */
    return (WSAStartup (wVersionRequested, &wsaData) == 0? 0: SOCKET_ERROR);
#elif (defined (DOES_SOCKETS))
    return (0);
#else
    connect_error_value = IP_NOSOCKETS;
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: sock_term

    Synopsis: Shuts-down the internet protocol.  On most systems this is a
    null call.  On some systems this unloads dynamic libraries.  Returns -1
    if there was an error, or 0 if everything was okay.  See sock_init().
    ---------------------------------------------------------------------[>]-*/

int
sock_term (void)
{
#if (defined (__WINDOWS__))
    WSACleanup ();
#endif
    return (0);
}


/*  ---------------------------------------------------------------------[<]-
    Function: passive_TCP

    Synopsis: Creates a passive bound TCP socket for the specified service.
    Returns socket number or INVALID_SOCKET.  If it returns INVALID_SOCKET,
    you can get the reason for the error by calling connect_error ().  This
    may be one of:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADSERVICE       Service cannot be converted to port number
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot create the passive socket
    IP_BINDERROR        Cannot bind to the port
    IP_LISTENERROR      Cannot listen to port
    </TABLE>
    ---------------------------------------------------------------------[>]-*/

sock_t
passive_TCP (
    char *service,                      /*  Service name or port as string   */
    int   queue_length                  /*  Queue length for listen()        */
)
{
    return (passive_socket (service, "tcp", queue_length));
}


/*  ---------------------------------------------------------------------[<]-
    Function: passive_UDP

    Synopsis: Creates a passive UDP socket for the specified service.
    Returns socket number or INVALID_SOCKET.  If it returns INVALID_SOCKET,
    you can get the reason for the error by calling connect_error ().  This
    may be one of:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADSERVICE       Service cannot be converted to port number
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot create the passive socket
    IP_BINDERROR        Cannot bind to the port
    </TABLE>
    ---------------------------------------------------------------------[>]-*/

sock_t
passive_UDP (
    char *service                       /*  Service name or port as string   */
)
{
    return (passive_socket (service, "udp", 0));
}


/*  ---------------------------------------------------------------------[<]-
    Function: passive_socket

    Synopsis:
    Creates a passive TCP or UDP socket.  This function allows a server
    program to create a master socket, so that connections can be accepted.
    Used by the passive_TCP and passive_UDP functions.  Returns a socket
    number or INVALID_SOCKET.  If it returns INVALID_SOCKET, you can get the
    reason for the error by calling connect_error ().  This may be one of:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADSERVICE       Service cannot be converted to port number
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot create the passive socket
    IP_BINDERROR        Cannot bind to the port
    IP_LISTENERROR      Cannot listen to port
    </TABLE>
    ---------------------------------------------------------------------[>]-*/

sock_t
passive_socket (
    char *service,                      /*  Service name or port as string   */
    char *protocol,                     /*  Protocol "tcp" or "udp"          */
    int   queue_length                  /*  Queue length for TCP sockets     */
)
{
#if (defined (DOES_SOCKETS))
    struct servent
        *pse;                           /*  Service information entry        */
    struct sockaddr_in
        sin;                            /*  Internet end-point address       */
    sock_t
        handle;                         /*  Socket from socket() call        */

    memset ((void *) &sin, 0, sizeof (sin));
    sin.sin_family      = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;

    /*  Map service name to port number                                      */
    pse = getservbyname (service, protocol);
    if (pse)
        sin.sin_port = htons ((dbyte) (ntohs (pse-> s_port) + ip_portbase));
    else
      {
        sin.sin_port = atoi (service);
        if (sin.sin_port == 0)          /*  Cannot get service entry         */
          {
            connect_error_value = IP_BADSERVICE;
            return (INVALID_SOCKET);
          }
        else
            sin.sin_port = htons ((dbyte) (sin.sin_port + ip_portbase));
      }
    handle = create_socket (protocol);
    if (handle == INVALID_SOCKET)       /*  Cannot create the socket         */
        return (INVALID_SOCKET);

    /*  Bind the socket                                                      */
    if (bind ((SOCKET) handle, (struct sockaddr *) &sin,
        sizeof (sin)) == SOCKET_ERROR)
      {
        connect_error_value = IP_BINDERROR;
        return (INVALID_SOCKET);        /*  Cannot bind to port              */
      }
    /*  Specify incoming queue length for stream socket                      */
    if (streq (protocol, "tcp")
    && listen ((SOCKET) handle, queue_length) == SOCKET_ERROR)
      {
        connect_error_value = IP_LISTENERROR;
        return (INVALID_SOCKET);        /*  Cannot listen on port            */
      }
    return (handle);
#else
    connect_error_value = IP_NOSOCKETS;
    return (INVALID_SOCKET);            /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: create_socket

    Synopsis:
    Creates a TCP or UDP socket.  The socket is not connected.  To use
    with TCP services you must bind or connect the socket.  You can use
    the socket with UDP services - e.g. read_UDP () - immediately.  Returns
    a socket number or INVALID_SOCKET, in which case you can get the reason
    for the error by calling connect_error ().  This may be one of:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot create the socket
    </TABLE>
    ---------------------------------------------------------------------[>]-*/

sock_t
create_socket (
    char *protocol                      /*  Protocol "tcp" or "udp"          */
)
{
#if (defined (DOES_SOCKETS))
    struct protoent
        *ppe;                           /*  Protocol information entry       */
    int
        sock_type;                      /*  Type of socket we want           */
    sock_t
        handle;                         /*  Socket from socket() call        */

#if (defined (__VMS__))                 /*  On older VAX, getprotobyname     */
    ppe-> p_proto = 0;                  /*    is not supplied                */
#else
    /*  Map protocol name to protocol number                                 */
    ppe = getprotobyname (protocol);
    if (ppe == NULL)                    /*  Cannot get protocol entry        */
      {
        connect_error_value = IP_BADPROTOCOL;
        return (INVALID_SOCKET);
      }
#endif
    /*  Use protocol string to choose a socket type                          */
    if (streq (protocol, "udp"))
        sock_type = SOCK_DGRAM;
    else
        sock_type = SOCK_STREAM;

    /*  Allocate a socket                                                    */
    handle = (sock_t) socket (AF_INET, sock_type, ppe-> p_proto);
    if (handle == INVALID_SOCKET)       /*  Cannot create passive socket     */
      {
        connect_error_value = IP_SOCKETERROR;
        return (INVALID_SOCKET);
      }
    setsockopt ((SOCKET) handle, SOL_SOCKET, SO_REUSEADDR, 0, 0);
    prepare_socket (handle);            /*  Ready socket for use             */
    return (handle);
#else
    connect_error_value = IP_NOSOCKETS;
    return (INVALID_SOCKET);            /*  Sockets not supported            */
#endif
}


#if (defined (DOES_SOCKETS))
/*  -------------------------------------------------------------------------
 *  prepare_socket -- internal
 *
 *  Does any system-specific work required to prepare a socket for normal
 *  use.  In Windows we have to set the socket to nonblocking mode.  In
 *  UNIX we do this if the ip_nonblock flag is set.
 */

static void
prepare_socket (sock_t handle)
{
#if (defined (__WINDOWS__))
    u_long
        command = ip_nonblock? 1: 0;
    /*  Redirect events and set non-blocking mode                            */
    if (handle != INVALID_SOCKET)
        ioctlsocket ((SOCKET) handle, FIONBIO, &command);
#else
    if (ip_nonblock)
        fcntl ((SOCKET) handle, F_SETFL, O_NONBLOCK
                | fcntl (handle, F_GETFL, 0));
#endif
}
#endif


/*  ---------------------------------------------------------------------[<]-
    Function: connect_TCP

    Synopsis:
    Creates a TCP socket and connects it to a specified host and service.
    Returns a socket number or INVALID_SOCKET.  In that case you can get
    the reason for the error by calling connect_error ().  This may be:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADHOST          Host is not known
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot open a socket
    IP_CONNECTERROR     Cannot connect socket
    </TABLE>
    The host name may be a full name, NULL or "" meaning the current host,
    or a dotted-decimal number.  The service may be a defined service, e.g.
    "echo", or a port number, specified as an ASCII string.  See
    connect_socket() for details.

    Examples:
    sock_t handle;
    handle = connect_TCP ("", "8080");
    handle = connect_TCP (NULL, "echo");
    handle = connect_TCP ("www.imatix.com", "http");
    ---------------------------------------------------------------------[>]-*/

sock_t
connect_TCP (
    char *host,                         /*  Host name                        */
    char *service                       /*  Service name                     */
)
{
    return (connect_socket (host,       /*  We have a host name              */
                            service,    /*  We have a service name           */
                            "tcp",      /*  Protocol is TCP                  */
                            NULL,       /*  No prepared address              */
                            3, 0));     /*  3 retries, no waiting            */
}


/*  ---------------------------------------------------------------------[<]-
    Function: connect_UDP

    Synopsis:
    Creates a UDP socket and connects it to a specified host and service.
    Returns a socket number or INVALID_SOCKET.  In that case you can get
    the reason for the error by calling connect_error ().  This may be:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADHOST          Host is not known
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot open a socket
    IP_CONNECTERROR     Cannot connect socket
    </TABLE>
    The host name may be a full name, NULL or "" meaning the current host,
    or a dotted-decimal number.  The service may be a defined service, e.g.
    "echo", or a port number, specified as an ASCII string.  See
    connect_socket() for details.

    Examples:
    sock_t handle;
    handle = connect_UDP ("", "7");
    handle = connect_UDP (NULL, "echo");
    handle = connect_UDP ("imatix.com", "echo");
    ---------------------------------------------------------------------[>]-*/

sock_t
connect_UDP (
    char *host,                         /*  Host name                        */
    char *service                       /*  Service name                     */
)
{
    return (connect_socket (host,       /*  We have a host name              */
                            service,    /*  We have a service name           */
                            "udp",      /*  Protocol is UDP                  */
                            NULL,       /*  No prepared address              */
                            3, 0));     /*  3 retries, no waiting            */
}


/*  ---------------------------------------------------------------------[<]-
    Function: connect_TCP_fast

    Synopsis: Creates a TCP socket and connects it to a specified host/port
    address.  Returns a socket number or INVALID_SOCKET.  In that case you
    can get the reason for the error by calling connect_error ().  This may
    be:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADHOST          Host is not known
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot open a socket
    IP_CONNECTERROR     Cannot connect socket
    </TABLE>
    This function is faster, if you know the host system address and port,
    than connect_TCP() because no translation is needed.
    You can get the host/address structure by calling address_end_point()
    or get_peer_addr().  See connect_socket() for details.
    ---------------------------------------------------------------------[>]-*/

sock_t
connect_TCP_fast (
    struct sockaddr_in *sin             /*  Socket address structure         */
)
{
    return (connect_socket (NULL,       /*  No host name                     */
                            NULL,       /*  No service name                  */
                            "tcp",      /*  Protocol is TCP                  */
                            sin,        /*  We have a prepared address       */
                            3, 0));     /*  3 retries, no waiting            */
}


/*  ---------------------------------------------------------------------[<]-
    Function: connect_UDP_fast

    Synopsis:
    Creates a UDP socket and connects it to a specified host/port address.
    Returns a socket number or INVALID_SOCKET.  In that case you can get
    the reason for the error by calling connect_error ().  This may be:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADHOST          Host is not known
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot open a socket
    IP_CONNECTERROR     Cannot connect socket
    </TABLE>
    This function is faster, if you know the host system address and port,
    than connect_UDP() because no translation is needed.
    You can get the host/address structure by calling address_end_point()
    or get_peer_addr().  See connect_socket() for details.
    ---------------------------------------------------------------------[>]-*/

sock_t
connect_UDP_fast (
    struct sockaddr_in *sin             /*  Socket address structure         */
)
{
    return (connect_socket (NULL,       /*  No host name                     */
                            NULL,       /*  No service name                  */
                            "udp",      /*  Protocol is UDP                  */
                            sin,        /*  We have a prepared address       */
                            3, 0));     /*  3 retries, no waiting            */
}


/*  ---------------------------------------------------------------------[<]-
    Function: connect_socket

    Synopsis:
    Makes a connection to a remote TCP or UDP port.  This allows a client
    program to start sending information to a server.  Used by the
    connect_TCP and connect_UDP functions.  Returns a socket number or
    INVALID_SOCKET.  If it returns INVALID_SOCKET, you can get the reason
    for the error by calling connect_error ().  This may be one of:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADHOST          Host is not known
    IP_BADPROTOCOL      Cannot understand protocol name
    IP_SOCKETERROR      Cannot open a socket
    IP_CONNECTERROR     Cannot connect socket
    </TABLE>
    Under Windows and UNIX (unless ip_nonblock is set to FALSE), may return
    a socket number even when the connection is not complete.  You should
    use select() for writing if you need to know when the connection has
    been established.

    The host name may be a full name, NULL or "" meaning the current host,
    or a dotted-decimal number.  The service may be a defined service, e.g.
    "echo", or a port number, specified as an ASCII string.  Alternatively,
    both these values may be NULL or "", in which case the function uses
    the host_addr argument to supply an address.  If you want to build the
    host_addr structure yourself, use build_sockaddr().

    Examples:
    struct sockaddr_in
        host_addr;
    sock_t
        handle;
    build_sockaddr (&host_addr, 32_bit_host, 16_bit_port);
    handle = connect_socket (NULL, NULL, "tcp", &host_addr, 3, 0);
    ---------------------------------------------------------------------[>]-*/

sock_t
connect_socket (
    char  *host,                        /*  Name of host, "" = localhost     */
    char  *service,                     /*  Service name or port as string   */
    char  *protocol,                    /*  Protocol "tcp" or "udp"          */
    struct sockaddr_in *host_addr,      /*  Socket address structure         */
    int    retry_max,                   /*  Max. number of retries           */
    int    retry_delay                  /*  Delay between retries            */
)
{
#if (defined (DOES_SOCKETS))
    struct sockaddr_in
        sin;                            /*  Internet end-point address       */
    sock_t
        handle = 0;                     /*  Created socket                   */
    int
        rc;                             /*  Return code from call            */

    /*  Format sockaddr_in port and hostname, and quit if that failed        */
    if (service && strused (service))
      {
        if (address_end_point (host, service, protocol, &sin))
            return (INVALID_SOCKET);
      }
    else
        sin = *host_addr;               /*  Fast connect requested           */

    /*  Connect socket and maybe retry a few times...                        */
    while (retry_max)
      {
        handle = create_socket (protocol);
        if (handle == INVALID_SOCKET)   /*  Unable to open a socket          */
            return (INVALID_SOCKET);

        rc = connect ((SOCKET) handle, (struct sockaddr *) &sin, sizeof (sin));
        if (rc == 0)
            break;                      /*  Connected okay                   */
        else
          {
#           if (defined (__WINDOWS__))
            if (WSAGetLastError () == WSAEWOULDBLOCK)
#           else
            if (errno == EINPROGRESS)
#           endif
                break;                  /*  Still connecting, but okay       */
          }
        /*  Retry if we have any attempts left                               */
        close_socket (handle);
        if (--retry_max == 0)           /*  Connection failed                */
          {
            connect_error_value = IP_CONNECTERROR;
            return (INVALID_SOCKET);
          }
        sleep (retry_delay);
      }
    return (handle);
#else
    connect_error_value = IP_NOSOCKETS;
    return (INVALID_SOCKET);            /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: connect_to_peer

    Synopsis:
    Connects an unconnected TCP or UDP socket to a peer specified by a
    sockaddr structure.  Returns 0 if the connection succeeded, or
    SOCKET_ERROR if there was a problem.  In the latter case you can
    get the reason for the error by calling sockmsg().  You must use
    select() before reading or writing to the socket, since the
    connection usually does not complete immediately.
    ---------------------------------------------------------------------[>]-*/

int
connect_to_peer (
    sock_t handle,                      /*  Socket to connect                */
    struct sockaddr_in *sin             /*  Socket address structure         */
)
{
#if (defined (DOES_SOCKETS))
    int
        rc;                             /*  Return code from call            */

    rc = connect ((SOCKET) handle, (struct sockaddr *) sin, sizeof (*sin));
#   if (defined (__WINDOWS__))
    return (win_error (rc));
#   else
    return (rc);
#   endif
#else
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: address_end_point

    Synopsis:
    Formats an address block (struct sockaddr_in) for the specified host
    and service (port) information.  Returns 0 if okay, SOCKET_ERROR if
    there was an error, in which case you can call connect_error () to get
    the reason for the error.  This may be one of:
    <TABLE>
    IP_NOSOCKETS        Sockets not supported on this system
    IP_BADHOST          Host is not known
    </TABLE>
    ---------------------------------------------------------------------[>]-*/

int
address_end_point (
    char  *host,                        /*  Name of host, "" = localhost     */
    char  *service,                     /*  Service name or port as string   */
    char  *protocol,                    /*  Protocol "tcp" or "udp"          */
    struct sockaddr_in *sin             /*  Block for formatted address      */
)
{
#if (defined (DOES_SOCKETS))
    struct hostent
        *phe;                           /*  Host information entry           */
    struct servent
        *pse;                           /*  Service information entry        */
    char
        hostname [MAXHOSTNAMELEN + 1];  /*  Name of this system              */
    int
        feedback = 0;                   /*  Assume everything works          */

    memset ((void *) sin, 0, sizeof (*sin));
    sin-> sin_family = AF_INET;

    /*  Map service name to a port number                                    */
    pse = getservbyname (service, protocol);
    if (pse)
        sin-> sin_port = pse-> s_port;
    else
        sin-> sin_port = htons ((dbyte) atoi (service));

    /*  Map host name to IP address, allowing for dotted decimal             */
    if (host && strused (host))
        strcpy (hostname, host);
    else
        gethostname (hostname, sizeof (hostname));

    phe = gethostbyname (hostname);
    if (phe)
        memcpy ((void *) &sin-> sin_addr, phe-> h_addr, phe-> h_length);
    else
      {
        sin-> sin_addr.s_addr = inet_addr (hostname);
        if (sin-> sin_addr.s_addr == INADDR_NONE)
          {                             /*  Cannot map to host               */
            connect_error_value = IP_BADHOST;
            feedback = (int) SOCKET_ERROR;
          }
      }
    return (feedback);
#else
    connect_error_value = IP_NOSOCKETS;
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: build_sockaddr

    Synopsis:
    Builds a socket address structure from the specified host and port
    addresses.  Does not return any value except the built structure.
    ---------------------------------------------------------------------[>]-*/

void
build_sockaddr (
    struct sockaddr_in *sin,            /*  Socket address structure         */
    qbyte  host,                        /*  32-bit host address              */
    dbyte  port                         /*  16-bit port number               */
)
{
    sin-> sin_family      = AF_INET;
    sin-> sin_addr.s_addr = htonl (host);
    sin-> sin_port        = htons (port);
}


/*  ---------------------------------------------------------------------[<]-
    Function: socket_hostaddr

    Synopsis: Returns a string containing the host address for the specified
    socket.  The string is formatted as a string "n.n.n.n".  Returns the
    address of a static area that is overwritten by each call.  Returns
    NULL if there was an error.  If sockets are not supported, returns the
    loopback address "127.0.0.1".
    ---------------------------------------------------------------------[>]-*/

char *
socket_hostaddr (sock_t handle)
{
#if (defined (DOES_SOCKETS))
    struct sockaddr_in
        sin;                            /*  Address of peer system           */

    get_peer_addr (handle, &sin, NULL, 0);
    return (inet_ntoa (sin.sin_addr));
#else
    return ("127.0.0.1");
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: accept_socket

    Synopsis: Accepts a connection on a specified master socket.  If you
    do not want to wait on this call, use select() to poll the socket until
    there is an incoming request, then call accept_socket.  Returns the
    number of the new slave socket, or INVALID_SOCKET if there was an error
    on the accept call.  You can handle errors as fatal except for EAGAIN
    which indicates that the operation would cause a non-blocking socket to
    block.
    ---------------------------------------------------------------------[>]-*/

sock_t
accept_socket (sock_t master_socket)
{
#if (defined (DOES_SOCKETS))
    sock_t
        slave_socket;                   /*  Connected slave socket           */
    struct sockaddr_in
        sin;                            /*  Address of connecting party      */
    int
        sin_length = sizeof (sin);      /*  Length of address                */

    slave_socket = accept ((SOCKET) master_socket,
                          (struct sockaddr *) &sin, &sin_length);

    /*  On non-Windows systems, accept returns -1 in case of error, which    */
    /*  is the same as INVALID_SOCKET.                                       */
#   if (defined (__WINDOWS__))
    if (slave_socket == INVALID_SOCKET)
      {
        int sock_errno = WSAGetLastError ();
        if (sock_errno == WSAEWOULDBLOCK || sock_errno == WSAEINPROGRESS)
            errno = EAGAIN;
      }
#   endif
    if (slave_socket != INVALID_SOCKET)
        prepare_socket (slave_socket);

    return (slave_socket);
#else
    connect_error_value = IP_NOSOCKETS;
    return (INVALID_SOCKET);            /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: connect_error

    Synopsis:
    Returns the last error code from one of the connection functions.  For
    portability in a multithreaded environment, call immediately after the
    call to the connection function.
    ---------------------------------------------------------------------[>]-*/

int
connect_error (void)
{
    return (connect_error_value);
}


/*  ---------------------------------------------------------------------[<]-
    Function: get_peer_addr

    Synopsis:
    Builds an address block (struct sockaddr_in) for the specified socket.
    Returns 0 if okay, SOCKET_ERROR if there was an error.  The socket must
    be connected.  If the name argument is not null, looks-up the host name
    and returns it.  The name is truncated to namesize characters, including
    a trailing null character.
    ---------------------------------------------------------------------[>]-*/

int
get_peer_addr (
    sock_t handle,                      /*  Socket to get address for        */
    struct sockaddr_in *sin,            /*  Block for formatted address      */
    char  *name,                        /*  Buffer for host name, or NULL    */
    int    namesize                     /*  Size of host name buffer         */
)
{
#if (defined (DOES_SOCKETS))
    int
        rc;                             /*  Return code from call            */
    struct hostent
        *phe;                           /*  Host information entry           */
    int
        sin_length = sizeof (*sin);     /*  Length of address                */

    /*  Get address for connected socket peer                                */
    rc = getpeername ((SOCKET) handle, (struct sockaddr *) sin, &sin_length);

    /*  Translate into host name string, only if wanted                      */
    if (name != NULL && rc == 0)
      {
        phe = gethostbyaddr ((char *) &sin-> sin_addr,
                             sizeof (sin-> sin_addr), AF_INET);
        if (phe)
          {
            strncpy (name, phe-> h_name, namesize);
            name [namesize - 1] = '\0';
          }
      }
#   if (defined (__WINDOWS__))
    return (win_error (rc));
#   else
    return (rc);
#   endif
#else
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: read_TCP

    Synopsis:
    Reads data from the socket.  On UNIX, VMS, OS/2, passes through to the
    standard read function; some other systems have particular ways of
    accessing sockets.  If there is an error on the read this function
    returns SOCKET_ERROR.  You can handle errors (in errno) as fatal except
    for EAGAIN which indicates that the operation would cause a non-blocking
    socket to block, and EPIPE or ECONNRESET which indicate that the socket
    was closed at the other end.
    ---------------------------------------------------------------------[>]-*/

int
read_TCP (
    sock_t handle,                      /*  Socket handle                    */
    void  *buffer,                      /*  Buffer to receive data           */
    size_t length                       /*  Maximum amount of data to read   */
)
{
#if (defined (DOES_SOCKETS))
#   if (defined (__UNIX__) || defined (__VMS__) || defined (__OS2__))
    return (read ((SOCKET) handle, buffer, length));
#   elif (defined (__WINDOWS__))
    int
        rc;                             /*  Return code from call            */

    rc = recv ((SOCKET) handle, buffer, length, 0);
    return (win_error (rc));
#   else
#       error "No code for function body."
#   endif
#else
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


#if (defined (__WINDOWS__))
/*  -------------------------------------------------------------------------
 *  win_error -- internal
 *
 *  For Winsockets only: fetches real error code and sticks it in errno,
 *  if the return code from the last call was SOCKET_ERROR.  Returns rc.
 */

static int
win_error (int rc)
{
    int
        sock_errno;                     /*  Real socket error number         */

    if (rc == (int) SOCKET_ERROR)
      {
        sock_errno = WSAGetLastError ();
        if (sock_errno == WSAEWOULDBLOCK || sock_errno == WSAEINPROGRESS)
            errno = EAGAIN;
        else
        if (sock_errno == WSAECONNRESET || sock_errno == WSAECONNABORTED)
            errno = ECONNRESET;
      }
    return (rc);
}
#endif


/*  ---------------------------------------------------------------------[<]-
    Function: write_TCP

    Synopsis:
    Writes data from the socket.  On UNIX, VMS, OS/2, calls the standard
    write function; some other systems have particular ways of accessing
    sockets.  If there is an error on the write this function returns
    SOCKET_ERROR.  You can handle errors (in errno) as fatal except for
    EAGAIN which indicates that the operation would cause a non-blocking
    socket to block, and EPIPE or ECONNRESET which indicate that the socket
    was closed at the other end.
    ---------------------------------------------------------------------[>]-*/

int
write_TCP (
    sock_t handle,                      /*  Socket handle                    */
    void  *buffer,                      /*  Buffer containing data           */
    size_t length                       /*  Amount of data to write          */
)
{
#if (defined (DOES_SOCKETS))
#   if (defined (__UNIX__) || defined (__VMS__) || defined (__OS2__))
    return (write ((SOCKET) handle, buffer, length));
#   elif (defined (__WINDOWS__))
    int
        rc;                             /*  Return code from call            */

    rc = send ((SOCKET) handle, buffer, length, 0);
    return (win_error (rc));
#   else
#       error "No code for function body."
#   endif
#else
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: read_UDP

    Synopsis:
    Reads data from a connected or unconnected UDP socket.  To prepare a
    connected UDP socket you call connect_UDP ().  This makes a connection
    to a specific port on a specific host, and returns a socket handle.
    When you call this function with a null value for the address argument,
    it assumes you are using a connected UDP socket.

    To prepare an unconnected UDP socket, call create_socket () with the
    string "udp" as argument.  This returns a sock_t handle that you can
    use in this function.  If you use an unconnected UDP socket you must
    provide an address structure.  The function places the remote host and
    port in this structure.  This lets you reply using write_UDP ().

    Generally a server can use unconnected sockets, and a client can use
    connected sockets.  You can also format an address for a specific host
    and port using the address_end_point () function.

    If there is an error on the read this function returns SOCKET_ERROR.
    You can handle errors (in errno) as fatal except for EAGAIN which
    indicates that the operation would cause a non-blocking socket to block.
    ---------------------------------------------------------------------[>]-*/

int
read_UDP (
    sock_t handle,                      /*  Socket handle                    */
    void  *buffer,                      /*  Buffer to receive data           */
    size_t length,                      /*  Maximum amount of data to read   */
    struct sockaddr_in *sin             /*  Block for address, or null       */
)
{
#if (defined (DOES_SOCKETS))
    int
        sin_length = sizeof (*sin),     /*  Length of address                */
        flags = 0,                      /*  Flags for call                   */
        rc;                             /*  Return code from call            */

    if (sin)
        /*  Read from unconnected UDP socket; we accept the address of the   */
        /*  sending party in the sin argument.                               */
        rc = recvfrom ((SOCKET) handle, buffer, length, flags,
                      (struct sockaddr *) sin, &sin_length);
    else
        /*  Read from a connected UDP socket; we don't need to get the       */
        /*  address, since we already know it.                               */
        rc = recv     ((SOCKET) handle, buffer, length, flags);

#   if (defined (__WINDOWS__))
    return (win_error (rc));
#   else
    return (rc);
#   endif
#else
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: write_UDP

    Synopsis:
    Writes data to a connected or unconnected UDP socket.  To prepare a
    connected UDP socket you call connect_UDP ().  This makes a connection
    to a specific port on a specific host, and returns a socket handle.
    When you call this function with a null value for the address argument,
    it assumes you are using a connected UDP socket.

    To prepare an unconnected UDP socket, call create_socket () with the
    string "udp" as argument.  This returns a sock_t handle that you can
    use in this function.  If you use an unconnected UDP socket you must
    provide an address structure containing a valid host and port.  You can
    get this information from a read_UDP () or through address_end_point ().

    If there is an error on the write this function returns SOCKET_ERROR.
    You can handle errors as fatal except for EAGAIN which indicates that
    the operation would cause a non-blocking socket to block.
    ---------------------------------------------------------------------[>]-*/

int
write_UDP (
    sock_t handle,                      /*  Socket handle                    */
    void  *buffer,                      /*  Buffer containing data           */
    size_t length,                      /*  Amount of data to write          */
    struct sockaddr_in *sin             /*  Address to send to, or null      */
)
{
#if (defined (DOES_SOCKETS))
    size_t
        sin_length = sizeof (*sin);     /*  Length of address                */
    int
        flags = 0,                      /*  Flags for call                   */
        rc;                             /*  Return code from call            */

    if (sin)
        /*  Write to unconnected UDP socket; we provide the address of       */
        /*  the receiving party in the sin argument.                         */
        rc = sendto ((SOCKET) handle, buffer, length, flags,
                    (struct sockaddr *) sin, sin_length);
    else
        /*  Write to a connected UDP socket; we don't need to supply         */
        /*  the address, since we already know it.                           */
        rc = send   ((SOCKET) handle, buffer, length, flags);

#   if (defined (__WINDOWS__))
    return (win_error (rc));
#   else
    return (rc);
#   endif
#else
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: close_socket

    Synopsis:
    Closes the socket.  On UNIX, VMS, OS/2 calls the standard close
    function; some other systems have particular ways of accessing sockets.
    If there is an error on the close this function returns SOCKET_ERROR.
    You can handle errors (in errno) as fatal except for EAGAIN which
    indicates that the operation would cause a non-blocking socket to block.
    ---------------------------------------------------------------------[>]-*/

int
close_socket (
    sock_t handle                       /*  Socket handle                    */
)
{
#if (defined (DOES_SOCKETS))
    if (!socket_is_alive (handle))
        return (0);
#   if (defined (__UNIX__) || defined (__VMS__) || defined (__OS2__))
    shutdown (handle, 2);
    return (close ((SOCKET) handle));
#   elif (defined (__WINDOWS__))
    {
    int
        rc;

    rc = closesocket ((SOCKET) handle);
    return (win_error (rc));
    }
#   else
#       error "No code for function body."
#   endif
#else
    return ((int) SOCKET_ERROR);        /*  Sockets not supported            */
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: get_host_name

    Synopsis: Returns a string containing the local hostname.  The returned
    string is in a static area.  Only performs the local hostname lookup one
    time; the returned value is cached for later repeated calls to this
    function.  If sockets are not supported, returns the value "localhost".
    ---------------------------------------------------------------------[>]-*/

char *
get_host_name (void)
{
#if (defined (DOES_SOCKETS))
    static char
        host_name [LINE_MAX + 1] = "";

    if (strnull (host_name))
        gethostname (host_name, LINE_MAX);
    return (host_name);
#else
    return ("localhost");
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: sockmsg

    Synopsis:
    Returns a string describing the cause of the last fatal error to occur
    a socket.  Should be called directly after a socket i/o operation; if you
    do other i/o operations or allow other threads to proceed in the meantime,
    the returned string may be incorrect.
    ---------------------------------------------------------------------[>]-*/

char *
sockmsg (void)
{
#if (defined (__WINDOWS__))
    char
        *message;

    switch (WSAGetLastError ())
      {
        case WSAEINTR:           message = "WSAEINTR";           break;
        case WSAEBADF:           message = "WSAEBADF";           break;
        case WSAEACCES:          message = "WSAEACCES";          break;
        case WSAEFAULT:          message = "WSAEFAULT";          break;
        case WSAEINVAL:          message = "WSAEINVAL";          break;
        case WSAEMFILE:          message = "WSAEMFILE";          break;
        case WSAEWOULDBLOCK:     message = "WSAEWOULDBLOCK";     break;
        case WSAEINPROGRESS:     message = "WSAEINPROGRESS";     break;
        case WSAEALREADY:        message = "WSAEALREADY";        break;
        case WSAENOTSOCK:        message = "WSAENOTSOCK";        break;
        case WSAEDESTADDRREQ:    message = "WSAEDESTADDRREQ";    break;
        case WSAEMSGSIZE:        message = "WSAEMSGSIZE";        break;
        case WSAEPROTOTYPE:      message = "WSAEPROTOTYPE";      break;
        case WSAENOPROTOOPT:     message = "WSAENOPROTOOPT";     break;
        case WSAEPROTONOSUPPORT: message = "WSAEPROTONOSUPPORT"; break;
        case WSAESOCKTNOSUPPORT: message = "WSAESOCKTNOSUPPORT"; break;
        case WSAEOPNOTSUPP:      message = "WSAEOPNOTSUPP";      break;
        case WSAEPFNOSUPPORT:    message = "WSAEPFNOSUPPORT";    break;
        case WSAEAFNOSUPPORT:    message = "WSAEAFNOSUPPORT";    break;
        case WSAEADDRINUSE:      message = "WSAEADDRINUSE";      break;
        case WSAEADDRNOTAVAIL:   message = "WSAEADDRNOTAVAIL";   break;
        case WSAENETDOWN:        message = "WSAENETDOWN";        break;
        case WSAENETUNREACH:     message = "WSAENETUNREACH";     break;
        case WSAENETRESET:       message = "WSAENETRESET";       break;
        case WSAECONNABORTED:    message = "WSAECONNABORTED";    break;
        case WSAECONNRESET:      message = "WSAECONNRESET";      break;
        case WSAENOBUFS:         message = "WSAENOBUFS";         break;
        case WSAEISCONN:         message = "WSAEISCONN";         break;
        case WSAENOTCONN:        message = "WSAENOTCONN";        break;
        case WSAESHUTDOWN:       message = "WSAESHUTDOWN";       break;
        case WSAETOOMANYREFS:    message = "WSAETOOMANYREFS";    break;
        case WSAETIMEDOUT:       message = "WSAETIMEDOUT";       break;
        case WSAECONNREFUSED:    message = "WSAECONNREFUSED";    break;
        case WSAELOOP:           message = "WSAELOOP";           break;
        case WSAENAMETOOLONG:    message = "WSAENAMETOOLONG";    break;
        case WSAEHOSTDOWN:       message = "WSAEHOSTDOWN";       break;
        case WSAEHOSTUNREACH:    message = "WSAEHOSTUNREACH";    break;
        case WSAENOTEMPTY:       message = "WSAENOTEMPTY";       break;
        case WSAEPROCLIM:        message = "WSAEPROCLIM";        break;
        case WSAEUSERS:          message = "WSAEUSERS";          break;
        case WSAEDQUOT:          message = "WSAEDQUOT";          break;
        case WSAESTALE:          message = "WSAESTALE";          break;
        case WSAEREMOTE:         message = "WSAEREMOTE";         break;
        case WSAEDISCON:         message = "WSAEDISCON";         break;
        case WSASYSNOTREADY:     message = "WSASYSNOTREADY";     break;
        case WSAVERNOTSUPPORTED: message = "WSAVERNOTSUPPORTED"; break;
        case WSANOTINITIALISED:  message = "WSANOTINITIALISED";  break;
        default:                 message = "No error";
      }
    return (message);
#else
    return (strerror (errno));
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: socket_is_alive

    Synopsis:
    Returns TRUE if the socket is open.  Returns FALSE if the socket is no
    longer accessible.  You can use this function to check that a socket has
    not been closed by the other party, before doing reading or writing.
    ---------------------------------------------------------------------[>]-*/

Bool
socket_is_alive (sock_t handle)
{
#if (defined (DOES_SOCKETS))
    int
        socket_type,
        socket_type_size = sizeof (SOCKET),
        rc;

    rc = getsockopt ((SOCKET) handle, SOL_SOCKET, SO_TYPE,
                    (char *) &socket_type, &socket_type_size);
    return (rc == 0);
#else
    return (FALSE);
#endif
}


/*  ---------------------------------------------------------------------[<]-
    Function: socket_error

    Synopsis: Returns an errno value for the socket, or 0 if no error was
    outstanding on the socket.  This function is useful if you are handling
    sockets using the select() function: this may return error indicators
    on sockets, without precision on the type of error.  This function will
    return the precise error number.  Errors like EINPROGRESS and EAGAIN
    can usually be ignored.
    ---------------------------------------------------------------------[>]-*/

int
socket_error (sock_t handle)
{
#if (defined (DOES_SOCKETS))
    return (getsockopt ((SOCKET) handle, SOL_SOCKET, SO_ERROR, 0, 0));
#else
    return (0);
#endif
}

#if (defined (__WINDOWS__))
/*  ---------------------------------------------------------------------[<]-
    Function: winsock_last_error

    Synopsis: Convert a winsock error into a errno value.
    ---------------------------------------------------------------------[>]-*/

int
winsock_last_error (void)
{
    int
        error = 0;

    switch (WSAGetLastError ())
      {
        case WSAEINTR:           error = EINTR;           break;
        case WSAEBADF:           error = EBADF;           break;
        case WSAEWOULDBLOCK:     error = EAGAIN;          break;
        case WSAEINPROGRESS:     error = EAGAIN;          break;
        case WSAECONNRESET:      error = EPIPE;           break;
        case WSAECONNABORTED:    error = EPIPE;           break;
        case WSAEINVAL:          error = EPIPE;           break;
#  if defined (WIN32)
        default:                 error = GetLastError ();
#  else
        default:                 error = errno;
#  endif
      }
    return (error);
}
#endif
