/*  ----------------------------------------------------------------<Prolog>-
    Title:      Memory allocation functions
    Package:    Standard Function Library (SFL)

    Written:    96/06/08  Pieter Hintjens <ph@imatix.com>
    Revised:    96/07/14  Pieter Hintjens <ph@imatix.com>

    Synopsis:   Encapsulated memory allocation functions.  Based on an
                article by Jim Schimandle in DDJ August 1990.

    Copyright:  Copyright (c) 1991-96 iMatix, parts copyright (c) DDJ 1990.
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "prelude.h"                    /*  Universal header file            */
#include "sflmem.h"                     /*  Prototypes for functions         */


/*- Constants ---------------------------------------------------------------*/

#define MEMTAG   0xa55aU                /*  Value for mh_tag                 */


/*- Structures --------------------------------------------------------------*/

typedef struct _MEMHDR MEMHDR;
struct _MEMHDR {                        /*  Memory block header info         */
    word     mh_tag;                    /*  Special ident tag                */
    size_t   mh_size;                   /*  Size of allocation block         */
    MEMHDR  *mh_next;                   /*  Next memory block                */
    MEMHDR  *mh_prev;                   /*  Previous memory block            */
    char    *mh_file;                   /*  File allocation was from         */
    word     mh_line;                   /*  Line allocation was from         */
};


/*- Macros ------------------------------------------------------------------*/

#define ALIGN_SIZE      sizeof (double)
#define RESERVE_SIZE    (((sizeof (MEMHDR) + (ALIGN_SIZE - 1)) \
                                            / ALIGN_SIZE) * ALIGN_SIZE)
#define CLIENT_2_HDR(a) ((MEMHDR *) (((char *) (a)) - RESERVE_SIZE))
#define HDR_2_CLIENT(a) ((void *)   (((char *) (a)) + RESERVE_SIZE))


/*- Global variables --------------------------------------------------------*/

int
    mem_trace = 0;                      /*  1 = trace                        */

/*- Local variables ---------------------------------------------------------*/

static long
    mem_size = 0;                       /*  Amount of memory used            */
static MEMHDR
    *memlist = NULL;                    /*  List of memory blocks            */
static long
    mem_alloc_count = 0,                /*  We keep count of calls to        */
    mem_free_count  = 0;                /*    mem_alloc() and mem_free()     */


/*- Local functions ---------------------------------------------------------*/

static void mem_tag_err      (void *ptr, char *filename, int lineno);
static void mem_list_add     (MEMHDR *);
static void mem_list_delete  (MEMHDR *);


/*  ---------------------------------------------------------------------[<]-
    Function: _mem_alloc

    Synopsis: Allocates a memory block.  Use the mem_alloc() macro to call
    this function.  Use _mem_free() to free blocks allocated with this
    function.  Returns a pointer to the allocated memory block, or NULL if
    there was not enough memory available.  The supplied source file name
    is assumed to be in a static area.
    ---------------------------------------------------------------------[>]-*/

void *
_mem_alloc(
    size_t size,                        /*  Desired size of memory block     */
    char  *filename,                    /*  Name of source file making call  */
    word   lineno                       /*  Line number in calling source    */
)
{
    MEMHDR
       *ptr;                            /*  Allocated memory block           */

    /*  Allocate block with extra space for the header                       */
    ptr = malloc (RESERVE_SIZE + size);
    if (ptr == NULL)
        return (NULL);

    if (mem_trace == 1)                 /*  Trace if required                */
        printf ("Allocate: %p\n", ptr);

    ptr-> mh_tag  = MEMTAG;             /*  Initialise block header          */
    ptr-> mh_size = size;               /*  Size of block                    */
    ptr-> mh_file = filename;           /*  Who allocated it                 */
    ptr-> mh_line = lineno;             /*    and where                      */

    mem_size += size;                   /*  Keep count of space used         */
    mem_alloc_count += 1;               /*    and number of allocations      */

    mem_list_add (ptr);                 /*  Add to list of blocks            */
    return (HDR_2_CLIENT (ptr));        /*   and return client address       */
}


/*  ---------------------------------------------------------------------[<]-
    Function: _mem_realloc

    Synopsis: Reallocates a memory block.  Use the mem_realloc() macro to
    call this function.  Accepts a pointer to a memory block and the desired
    size of the new memory block.  Returns the address of the new memory
    block, or NULL if there was not enough memory available.  If the
    specified block was not correctly allocated, dumps the memory allocation
    list and exits.
    ---------------------------------------------------------------------[>]-*/

void *
_mem_realloc(
    void   *client_ptr,                 /*  Block of memory to reallocate    */
    size_t  size,                       /*  Desired size of memory block     */
    char   *filename,                   /*  Name of source file making call  */
    word    lineno                      /*  Line number in calling source    */
)
{
    MEMHDR
        *ptr;

    ASSERT (client_ptr);

    /*  Check that block is valid                                            */
    ptr = CLIENT_2_HDR (client_ptr);
    if (ptr-> mh_tag != MEMTAG)
        mem_tag_err (ptr, filename, lineno);

    /*  Invalidate header                                                    */
    ptr-> mh_tag = (word) ~MEMTAG;
    mem_size -= ptr-> mh_size;
    mem_free_count += 1;
    mem_list_delete (ptr);              /*  Remove block from list           */

    /*  Reallocate memory block                                              */
    ptr = (MEMHDR *) realloc (ptr, RESERVE_SIZE + size);
    if (ptr == NULL)
        return (NULL);

    if (mem_trace == 1)                 /*  Trace if required                */
        printf ("Reallocate: %p\n", ptr);

    /*  Update header                                                        */
    ptr-> mh_tag  = MEMTAG;
    ptr-> mh_size = size;
    ptr-> mh_file = filename;
    ptr-> mh_line = lineno;
    mem_size += size;                   /*  Keep count of space used         */
    mem_alloc_count += 1;               /*    and number of allocations      */
    mem_list_add (ptr);                 /*  Add block to list                */

    return (HDR_2_CLIENT (ptr));
}


/*  ---------------------------------------------------------------------[<]-
    Function: _mem_strdup

    Synopsis: Saves a string in dynamic memory.  Use the mem_strdup() macro
    to call this function.  The caller is responsible for freeing the space
    allocated when it is no longer needed.  Returns a pointer to the
    allocated string, which holds a copy of the parameter string.  Returns
    NULL if there was insufficient heap storage available to allocate the
    string, or if the original string was itself NULL.
    ---------------------------------------------------------------------[>]-*/

char *
_mem_strdup(
    char *string,                       /*  String to copy                   */
    char *filename,                     /*  Name of source file making call  */
    word  lineno                        /*  Line number in calling source    */
)
{
    char *copy;

    if (string)                         /*  If string not null, copy it      */
      {
        copy = _mem_alloc (strlen (string) + 1, filename, lineno);
        if (copy)
            strcpy (copy, string);
      }
    else
        copy = NULL;                    /*  Just pass-through a NULL         */

    return (copy);
}


/*  ---------------------------------------------------------------------[<]-
    Function: _mem_strfree

    Synopsis: Releases memory occupied by a string.  Use the mem_strfree()
    macro to call this function.  Call this function to free strings
    allocated using _mem_strdup().  Accepts the address of a char pointer
    as argument: if the pointer is not null, the string is freed, and the
    pointer is set to null.  Returns the address of the modified pointer.

    Examples:
    char
        *string1 = NULL,
        *string2 = NULL;
    string1 = mem_strdup ("This is a string");
    mem_strfree (&string1);
    mem_strfree (&string2);
    ---------------------------------------------------------------------[>]-*/

char **
_mem_strfree (
    char **string,                      /*  Address of string to free        */
    char  *filename,                    /*  Name of source file making call  */
    word   lineno                       /*  Line number in calling source    */
)
{
    ASSERT (string);
    if (*string)
      {
        _mem_free (*string, filename, lineno);
        *string = NULL;
      }
    return (string);
}


/*  ---------------------------------------------------------------------[<]-
    Function: _mem_free

    Synopsis: Releases memory previously allocated by _mem_alloc(),
    _mem_realloc(), or _mem_strdup().  Use the mem_free() macro to call
    this function.  If the specified block was not correctly allocated,
    dumps the memory allocation list and exits.  If you specify a null
    address, does nothing.
    ---------------------------------------------------------------------[>]-*/

void
_mem_free (
    void *client_ptr,                   /*  Block of memory to free          */
    char *filename,                     /*  Name of source file making call  */
    word  lineno                        /*  Line number in calling source    */
)
{
    MEMHDR
       *ptr;

    if (client_ptr == NULL)             /*  Do nothing if address is null    */
        return;

    /*  Check for valid block                                                */
    ptr = CLIENT_2_HDR (client_ptr);
    if (ptr-> mh_tag != MEMTAG)
        mem_tag_err (ptr, filename, lineno);

    if (mem_trace == 1)                 /*  Trace if required                */
        printf ("Free: %p\n", ptr);

    /*  Invalidate header                                                    */
    ptr-> mh_tag = (word) ~MEMTAG;
    mem_size -= ptr-> mh_size;
    mem_free_count += 1;
    mem_list_delete (ptr);              /*  Remove block from list           */

    free (ptr);
}


/*  ---------------------------------------------------------------------[<]-
    Function: _mem_assert

    Synopsis: Checks that all allocated memory was freed.  Use the
    mem_assert macro to call this function.  If any memory is still left
    allocated, displays the memory list on stderr and aborts.  Generally
    we use this function at the end of a program, after deallocating all
    memory.  If any memory has not been allocated, we get a nice list and
    an abort.  Our principle is that any memory allocation must be matched
    by a free somewhere in the code.
    ---------------------------------------------------------------------[>]-*/

void
_mem_assert (
    char  *filename,                    /*  Name of source file making call  */
    word   lineno                       /*  Line number in calling source    */
)
{
    if (mem_size != 0)
      {
        fflush  (stdout);
        fprintf (stderr, "Clean-memory assertion failed - %s (%d)\n",
                          filename, lineno);
        mem_display (stderr);
        abort ();
      }
}


/*  ---------------------------------------------------------------------[<]-
    Function: mem_used

    Synopsis: Returns the number of bytes currently allocated using the
    memory management system. The value returned is simply the sum of the
    size requests to allocation routines.  It does not reflect any overhead
    required by the memory management system.
    ---------------------------------------------------------------------[>]-*/

long
mem_used (void)
{
    return (mem_size);
}


/*  ---------------------------------------------------------------------[<]-
    Function: mem_allocs

    Synopsis: Returns the number of blocks allocated in total.  Use this
    to get an idea of the activity of the memory management system.  When
    program ends cleanly, mem_allocs () should be equal to mem_frees().
    ---------------------------------------------------------------------[>]-*/

long
mem_allocs (void)
{
    return (mem_alloc_count);
}


/*  ---------------------------------------------------------------------[<]-
    Function: mem_frees

    Synopsis: Returns the number of blocks freeed in total.   Use this
    to get an idea of the activity of the memory management system.  When
    program ends cleanly, mem_allocs () should be equal to mem_frees().
    ---------------------------------------------------------------------[>]-*/

long
mem_frees (void)
{
    return (mem_free_count);
}


/*  ---------------------------------------------------------------------[<]-
    Function: mem_display

    Synopsis: Displays the contents of the memory allocation list.
    ---------------------------------------------------------------------[>]-*/

void
mem_display (
    FILE *fp                            /*  File to dump display to          */
)
{
    MEMHDR
        *ptr;
    int
        index;

    fprintf (fp, "Index   Size  File(Line) - total size %lu\n", mem_size);
    index = 0;
    ptr = memlist;
    while (ptr != NULL)
      {
        fprintf (fp, "%-5d %6u", index++, (unsigned) ptr-> mh_size);
        fprintf (fp, "  %s(%d)", ptr-> mh_file, ptr-> mh_line);
        if (ptr-> mh_tag != MEMTAG)
            fprintf (fp, " INVALID");

        fprintf (fp, "\n");
        ptr = ptr-> mh_next;
      }
    fflush (fp);
}


/* ---------------------------------------------------------------------------
 *  mem_list_add -- internal
 *
 *  Add block of memory to list
 */

static void
mem_list_add (MEMHDR *ptr)
{
    ptr-> mh_next = memlist;
    ptr-> mh_prev = NULL;
    if (memlist != NULL)
        memlist-> mh_prev = ptr;

    memlist = ptr;
}


/* ---------------------------------------------------------------------------
 *  mem_list_delete -- internal
 *
 *  Delete block from list
 */

static void
mem_list_delete (MEMHDR *ptr)
{
    if (ptr-> mh_next != NULL)
        ptr-> mh_next-> mh_prev = ptr-> mh_prev;

    if (ptr-> mh_prev != NULL)
        ptr-> mh_prev->mh_next = ptr-> mh_next;
    else
        memlist = ptr-> mh_next;
}


/* ---------------------------------------------------------------------------
 *  mem_tag_err -- internal
 *
 *  Display memory tag error
 */

static void
mem_tag_err (void *ptr, char *filename, int lineno)
{
    fflush  (stdout);
    fprintf (stderr, "Memory tag error - %p - %s(%d)\n",
                     ptr, filename, lineno);
    mem_display (stderr);
    abort ();
}
