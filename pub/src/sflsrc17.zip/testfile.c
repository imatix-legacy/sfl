/*  ----------------------------------------------------------------<Prolog>-
    Name:       testfile.c
    Title:      Test program for file access functions
    Package:    Standard Function Library (SFL)

    Written:    96/12/13  iMatix SFL project team <sfl@imatix.com>
    Revised:    97/09/08

    Copyright:  Copyright (c) 1991-97 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "sfl.h"

int main (int argc, char *argv [])
{
    if (argc < 2)
        puts ("Syntax: testfile filename");
    else
    if (file_cycle (argv [1]))
        puts ("file_cycle okay");
    else
        puts ("file_cycle failed");

    return (EXIT_SUCCESS);
}
