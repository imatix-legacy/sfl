#include "prelude.h"
#include "sflproc.h"

#define DEVICE    "/dev/pts/3"
#define COMMAND   "run DR.gnt"

void handler (int sigvalue)
{
    printf ("Signal received: %d\n", sigvalue);
    exit (0);
}

void main (int argc, char *argv [])
{
    static char *envv [] = { "DATABASE=testdata", NULL};
    pid_t pid;
    struct itimerval
        timeout;                      

    signal (SIGALRM, &handler);

    pid = process_create (COMMAND, NULL, NULL,
                          DEVICE, DEVICE, DEVICE, envv, FALSE);
    if (pid == -1)
        puts (strerror (errno));
    else
      {
        printf ("Created process = %d\n", pid);
        FOREVER
          {
            switch (process_status (pid))
              {
                case PROCESS_ENDED_OK:
                    puts ("Ended okay");
                    return;
                case PROCESS_ENDED_ERROR:  
                    printf ("Ended with error: %s\n", strerror (process_errno));
                    return;
                case PROCESS_INTERRUPTED: 
                    puts ("Interrupted");
                    return;
                case PROCESS_RUNNING:
                    printf (".");
              }
          }
      }
}
