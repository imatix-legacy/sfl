#include "sfl.h"                        /*  SFL functions                    */

int
main (int argc, char *argv [])
{
    puts (conv_number_str ("12345.67", 34, '.', 2, 1, 0, 0));
    puts (conv_number_str ("12345678", 34, '.', 2, 1, 0, 0));
}
