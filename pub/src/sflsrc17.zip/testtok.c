/*  ----------------------------------------------------------------<Prolog>-
    Name:       testtok.c
    Title:      Test program for token functions
    Package:    Standard Function Library (SFL)

    Written:    96/09/10  iMatix SFL project team <sfl@imatix.com>
    Revised:    97/09/08

    Synopsis:   Testtok tests the functions in sfltok.c.

    Copyright:  Copyright (c) 1991-97 iMatix
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SFL License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "sfl.h"

int main (int argc, char *argv [])
{
    char
        **tokens1,
        **tokens2,
        **ptr;
    tokens1 = tok_split ("This is  a  string with various words");
    tokens2 = tok_split ("Yet another    string!!! :-)");

    for (ptr = tokens1; *ptr; ptr++)
        printf ("%s ", *ptr);
    printf ("\n");

    for (ptr = tokens2; *ptr; ptr++)
        printf ("%s ", *ptr);
    printf ("\n");

    tok_free (tokens1);
    tok_free (tokens2);
}
